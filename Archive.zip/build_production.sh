#!/usr/bin/env bash
set -euo pipefail

echo "🏗️ PRODUCTION BUILD START - $(date)"
echo "⏱️  Estimated time: 3-5 minutes"
echo ""

# Phase 1: Python dependencies (SLOWEST - numpy, scipy, reportlab)
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🏗️ Phase 1/3: Python dependencies (2-3 min)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "📦 Installing heavy packages (numpy, scipy, reportlab)..."
pip install --no-cache-dir --quiet . || {
    echo "❌ Python install failed! Retrying with verbose output..."
    pip install .
}
echo "✅ Python packages installed - $(date)"
echo ""

# Phase 2: Frontend (FAST with cache)
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🏗️ Phase 2/3: Frontend build (30-60 sec)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
cd client
echo "📦 Installing frontend dependencies..."
npm install --prefer-offline --no-audit --no-fund --legacy-peer-deps --loglevel error
echo "🔨 Building frontend with Vite..."
npm run build
cd ..

echo "📦 Copying client/dist → dist/ (Flask static root)..."
# Clean old dist completely
rm -rf dist
mkdir -p dist
# Copy fresh build
cp -R client/dist/* dist/
echo "✅ Frontend copied to dist/"

echo "🔍 Validating build integrity..."
# Add build timestamp for tracking
date +%s > dist/build_id.txt
# Verify asset integrity: ensure index.html points to existing JS file
ASSET=$(grep -o 'assets/index-[^"]\+\.js' dist/index.html | head -n1)
if [ -z "$ASSET" ]; then
    echo "❌ ERROR: No JS asset found in index.html!"
    exit 1
fi
if [ ! -f "dist/$ASSET" ]; then
    echo "❌ ERROR: Asset mismatch! index.html references $ASSET but file doesn't exist!"
    exit 1
fi
echo "✅ Build integrity verified: $ASSET exists"
echo "✅ Frontend built and validated - $(date)"
echo ""

# Phase 3: Baileys (FAST)
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🏗️ Phase 3/3: Baileys WhatsApp (30 sec)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
cd services/whatsapp
echo "📦 Installing Baileys dependencies..."
npm install --prefer-offline --no-audit --no-fund --legacy-peer-deps --loglevel error
cd ../..
echo "✅ Baileys ready - $(date)"
echo ""

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ PRODUCTION BUILD COMPLETE - $(date)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📦 Python packages: ✅ Installed"
echo "📦 Frontend build:  ✅ client/dist/"
echo "📦 Baileys service: ✅ services/whatsapp/node_modules/"
echo ""
echo "🚀 Ready for deployment!"
