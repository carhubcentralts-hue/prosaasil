# 🔧 מדריך תיקון דטאבייס הפריסה

## הבעיה
admin@admin.com מופיע בעסק ספציפי (business_id=10) במקום להיות משתמש גלובלי (business_id=NULL)

## 📋 תיקון חד-פעמי - 3 דקות

### אופציה 1: דרך Replit UI (מומלץ)

1. **פתח את הדטאבייס של הפריסה:**
   - Replit → לחץ על "Database" בצד שמאל
   - בחר "Production" (לא Development!)
   - לחץ על "Console" או "SQL Editor"

2. **הדבק והרץ את ה-SQL הבא:**
   ```sql
   UPDATE users 
   SET business_id = NULL, role = 'system_admin', is_active = true
   WHERE email = 'admin@admin.com';
   ```

3. **וודא שהתיקון עבד:**
   ```sql
   SELECT id, email, role, business_id 
   FROM users 
   WHERE email = 'admin@admin.com';
   ```
   
   **תוצאה צפויה:**
   ```
   id | email              | role         | business_id
   8  | admin@admin.com    | system_admin | NULL
   ```

### אופציה 2: דרך קובץ SQL (אם יש גישה ל-psql)

```bash
# קובץ מוכן: server/scripts/fix_production_admin.sql
psql $DATABASE_URL -f server/scripts/fix_production_admin.sql
```

---

## 🌱 Seed Script - מבטיח עקביות תמיד

### מה זה עושה?
- **מוודא** שמשתמש system_admin גלובלי תמיד קיים
- **מתקן** אוטומטית אם משהו השתבש
- **אידמפוטנטי** - בטוח להריץ כמה פעמים

### איך להריץ:

**בסביבת פיתוח:**
```bash
python server/scripts/init_seed_data.py
```

**בפריסה (אוטומטי):**
הקובץ ירוץ אוטומטית בכל deploy אם תוסיף ל-`server/app.py`:

```python
# בתחילת האפליקציה
with app.app_context():
    from server.scripts.init_seed_data import seed_system_admin
    seed_system_admin()
```

---

## ✅ בדיקה שהכל תקין

### 1. בדוק בפיתוח:
```bash
psql $DATABASE_URL -c "SELECT email, role, business_id FROM users WHERE email = 'admin@admin.com';"
```

### 2. בדוק בפריסה:
- התחבר לדטאבייס Production
- הרץ את אותו query

### 3. בדוק ב-UI:
- התחבר עם admin@admin.com / admin123
- לחץ על "ניהול משתמשים" בעסק כלשהו
- **admin@admin.com לא אמור להופיע ברשימה!** (הוא גלובלי)

---

## 🔒 אבטחה

- ✅ הסיסמה admin123 היא **זמנית** - שנה אותה לאחר הכניסה הראשונה!
- ✅ system_admin רואה הכל אבל לא מופיע בניהול משתמשים של עסק
- ✅ כל פעולה מתועדת בלוגים

---

## 🚀 סנכרון עתידי בין סביבות

### כלל זהב:
**כל שינוי בדטאבייס צריך migration script שירוץ גם בפריסה!**

### תהליך מומלץ:
1. שנה schema ב-`shared/schema.ts`
2. הרץ `npm run db:push` בפיתוח
3. תעד את השינוי ב-migration script
4. בפריסה: הרץ את אותו migration

---

## 📞 צריך עזרה?
אם משהו לא עובד, בדוק:
1. ✅ האם התחברת לדטאבייס הנכון? (Production vs Development)
2. ✅ האם יש הרשאות לעדכן את הטבלה users?
3. ✅ האם ה-query רץ ללא שגיאות?
