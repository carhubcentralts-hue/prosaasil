async function globalTeardown() {
  console.log('🧹 Running global teardown');
  // Add any cleanup logic here if needed
  console.log('✅ Global teardown completed');
}

export default globalTeardown;