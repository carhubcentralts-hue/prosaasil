"""
Database configuration for Hebrew AI Call Center CRM
SQLAlchemy setup for production-ready database operations
"""
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()