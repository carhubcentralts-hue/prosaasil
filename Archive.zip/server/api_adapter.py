"""
API Adapter Layer - Frontend Compatibility
שכבת מתאם API - התאמה לפרונט-אנד
"""
from flask import Blueprint, jsonify, request, session, g  # BUILD 136: Added g for @require_api_auth
from server.models_sql import Business, CallLog, WhatsAppMessage, Customer, User, Payment, Lead, db
from server.auth_api import require_api_auth  # BUILD 136: Added for proper authentication
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

api_adapter_bp = Blueprint('api_adapter', __name__)

def check_permissions(required_roles):
    """Check user permissions for adapter endpoints with proper impersonation support"""
    # Enhanced debugging for session state
    logger.debug(f"Session keys available: {list(session.keys())}")
    
    # Get user from session (both possible keys for robustness)
    user = session.get('user') or session.get('al_user')
    
    # Proper impersonation detection (both flags must be present)
    is_impersonating = bool(session.get('impersonating') and session.get('impersonated_tenant_id'))
    
    # Enhanced logging for debugging
    if is_impersonating:
        logger.debug(f"Impersonation mode detected: tenant_id={session.get('impersonated_tenant_id')}, user={user.get('email') if user else None}")
    
    # Handle impersonation mode properly
    if is_impersonating and user:
        # In impersonation mode, allow admin/manager to access business-level endpoints
        if user.get('role') in ['admin', 'manager'] and 'business' in required_roles:
            logger.debug(f"Impersonation access granted: {user.get('role')} {user.get('email')} accessing as business {session.get('impersonated_tenant_id')}")
            return None  # Permission granted
    
    # Check if user exists in session
    if not user:
        logger.warning(f"Permission denied - no user found. Session keys: {list(session.keys())}, cookies present: {bool(request.cookies)}")
        return jsonify({"error": "forbidden", "requiredRole": "authenticated"}), 403
    
    # Normal role checking
    user_role = user.get('role', '')
    logger.debug(f"User role: {user_role}, required: {required_roles}, impersonating: {is_impersonating}")
    
    if user_role not in required_roles:
        logger.warning(f"Permission denied - user role '{user_role}' not in required roles: {required_roles}")
        return jsonify({"error": "forbidden", "requiredRole": "/".join(required_roles)}), 403
    
    logger.debug(f"Permission granted for user {user.get('email')} with role {user_role}")
    return None  # Permission granted

# === DASHBOARD ENDPOINTS ===

@api_adapter_bp.route('/api/dashboard/stats', methods=['GET'])
@require_api_auth(['system_admin', 'owner', 'admin', 'agent'])  # BUILD 138 FIX: Use current role names only
def dashboard_stats():
    """BUILD 136: Business-scoped dashboard stats - uses g.tenant from @require_api_auth"""
    import traceback
    
    try:
        # BUILD 136 FIX: Use g.tenant populated by @require_api_auth
        tenant_id = g.tenant
        if not tenant_id:
            return jsonify({"error": "No tenant access"}), 403
        
        # Get time filter from query params (default: today)
        time_filter = request.args.get('time_filter', 'today')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # Calculate date range based on filter
        today = datetime.utcnow().date()
        now = datetime.utcnow()
        
        if time_filter == 'custom' and start_date and end_date:
            date_start = datetime.strptime(start_date, '%Y-%m-%d').date()
            date_end = datetime.strptime(end_date, '%Y-%m-%d').date()
        elif time_filter == '7days' or time_filter == 'week':
            date_start = today - timedelta(days=7)
            date_end = today
        elif time_filter == 'month' or time_filter == '30days':
            date_start = today - timedelta(days=30)
            date_end = today
        else:  # today or default
            date_start = today
            date_end = today
        
        # 🔥 BUILD 171: Convert date objects to datetime for proper comparison
        week_ago = datetime.combine(today - timedelta(days=7), datetime.min.time())
        
        # BUILD 135: Calls stats - FILTERED by tenant_id and date range
        from sqlalchemy import func as sql_func
        
        # 🔥 BUILD 171: Wrap each query in try-except for better error isolation
        try:
            calls_in_range = CallLog.query.filter(
                CallLog.business_id == tenant_id,
                db.func.date(CallLog.created_at) >= date_start,
                db.func.date(CallLog.created_at) <= date_end
            ).count()
        except Exception as e:
            logger.error(f"Error in calls_in_range query: {e}")
            calls_in_range = 0
        
        try:
            calls_last7d = CallLog.query.filter(
                CallLog.business_id == tenant_id,
                CallLog.created_at >= week_ago
            ).count()
        except Exception as e:
            logger.error(f"Error in calls_last7d query: {e}")
            calls_last7d = 0
        
        # Real average handle time
        avg_handle_sec = 0
        
        # BUILD 156: WhatsApp stats - COUNT UNIQUE CHATS (not messages)
        try:
            # Count distinct phone numbers that had conversations in date range
            whatsapp_in_range = db.session.query(sql_func.count(sql_func.distinct(WhatsAppMessage.to_number))).filter(
                WhatsAppMessage.business_id == tenant_id,
                db.func.date(WhatsAppMessage.created_at) >= date_start,
                db.func.date(WhatsAppMessage.created_at) <= date_end
            ).scalar() or 0
        except Exception as e:
            logger.error(f"Error in whatsapp_in_range query: {e}")
            whatsapp_in_range = 0
        
        try:
            # Count distinct phone numbers that had conversations in last 7 days
            whatsapp_last7d = db.session.query(sql_func.count(sql_func.distinct(WhatsAppMessage.to_number))).filter(
                WhatsAppMessage.business_id == tenant_id,
                WhatsAppMessage.created_at >= week_ago
            ).scalar() or 0
        except Exception as e:
            logger.error(f"Error in whatsapp_last7d query: {e}")
            whatsapp_last7d = 0
        
        try:
            # BUILD 156: Count unique chats with unread messages (not individual messages)
            unread = db.session.query(sql_func.count(sql_func.distinct(WhatsAppMessage.to_number))).filter(
                WhatsAppMessage.business_id == tenant_id,
                WhatsAppMessage.status == 'received'
            ).scalar() or 0
        except Exception as e:
            logger.error(f"Error in unread query: {e}")
            unread = 0
        
        # BUILD 135: Real revenue stats - FILTERED by tenant_id
        # BUILD 173: Payment table may not exist on older production DBs
        from sqlalchemy import func
        revenue_this_month = 0
        revenue_ytd = 0
        revenue_degraded = False  # Flag to indicate degraded data
        try:
            revenue_this_month = Payment.query.with_entities(func.sum(Payment.amount)).filter(
                Payment.business_id == tenant_id,
                func.extract('month', Payment.created_at) == today.month,
                func.extract('year', Payment.created_at) == today.year
            ).scalar() or 0
        except Exception as e:
            err_str = str(e).lower()
            if 'undefinedtable' in err_str or 'does not exist' in err_str or 'payments' in err_str:
                logger.warning(f"Payment table does not exist - returning 0 for revenue")
                revenue_degraded = True
            else:
                logger.error(f"Unexpected Payment query error: {e}")
                revenue_degraded = True
            
        try:
            revenue_ytd = Payment.query.with_entities(func.sum(Payment.amount)).filter(
                Payment.business_id == tenant_id,
                func.extract('year', Payment.created_at) == today.year
            ).scalar() or 0
        except Exception as e:
            err_str = str(e).lower()
            if 'undefinedtable' in err_str or 'does not exist' in err_str or 'payments' in err_str:
                logger.warning(f"Payment table does not exist - returning 0 for YTD revenue")
                revenue_degraded = True
            else:
                logger.error(f"Unexpected Payment YTD query error: {e}")
                revenue_degraded = True
        
        return jsonify({
            "calls": {
                "today": calls_in_range,
                "last7d": calls_last7d,
                "avgHandleSec": avg_handle_sec
            },
            "whatsapp": {
                "today": whatsapp_in_range,
                "last7d": whatsapp_last7d,
                "unread": unread
            },
            "revenue": {
                "thisMonth": revenue_this_month,
                "ytd": revenue_ytd,
                "degraded": revenue_degraded  # BUILD 173: Flag to indicate data quality issues
            },
            "filter": {
                "type": time_filter,
                "start": str(date_start),
                "end": str(date_end)
            }
        })
        
    except Exception as e:
        logger.error(f"Error in dashboard_stats: {e}")
        logger.error(f"Traceback: {traceback.format_exc()}")
        return jsonify({"error": "internal_server_error"}), 500

@api_adapter_bp.route('/api/dashboard/activity', methods=['GET'])
@require_api_auth(['system_admin', 'owner', 'admin', 'agent'])  # BUILD 138 FIX: Use current role names only
def dashboard_activity():
    """BUILD 136: Business-scoped recent activity - uses g.tenant from @require_api_auth"""
    import traceback
    
    try:
        # BUILD 136 FIX: Use g.tenant populated by @require_api_auth
        tenant_id = g.tenant
        if not tenant_id:
            return jsonify({"error": "No tenant access"}), 403
        
        # Get time filter from query params
        time_filter = request.args.get('time_filter', 'today')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        # Calculate date range
        today = datetime.utcnow().date()
        
        if time_filter == 'custom' and start_date and end_date:
            date_start = datetime.strptime(start_date, '%Y-%m-%d').date()
            date_end = datetime.strptime(end_date, '%Y-%m-%d').date()
        elif time_filter == '7days' or time_filter == 'week':
            date_start = today - timedelta(days=7)
            date_end = today
        elif time_filter == 'month' or time_filter == '30days':
            date_start = today - timedelta(days=30)
            date_end = today
        else:  # today or default
            date_start = today
            date_end = today
        
        # 🔥 BUILD 171: Wrap each query with error handling
        # BUILD 135: Get recent WhatsApp messages - FILTERED by tenant_id and date
        try:
            recent_whatsapp = WhatsAppMessage.query.filter(
                WhatsAppMessage.business_id == tenant_id,
                db.func.date(WhatsAppMessage.created_at) >= date_start,
                db.func.date(WhatsAppMessage.created_at) <= date_end
            ).order_by(
                WhatsAppMessage.created_at.desc()
            ).limit(20).all()
        except Exception as e:
            logger.error(f"Error fetching whatsapp messages: {e}")
            recent_whatsapp = []
        
        # BUILD 135: Get recent calls - FILTERED by tenant_id and date
        try:
            recent_calls = CallLog.query.filter(
                CallLog.business_id == tenant_id,
                db.func.date(CallLog.created_at) >= date_start,
                db.func.date(CallLog.created_at) <= date_end
            ).order_by(
                CallLog.created_at.desc()
            ).limit(20).all()
        except Exception as e:
            logger.error(f"Error fetching calls: {e}")
            recent_calls = []
        
        activities = []
        
        # BUILD 170: Cache lead lookups by customer_id to avoid N+1 queries
        customer_to_lead = {}
        
        # Add WhatsApp activities (with None check for created_at)
        for msg in recent_whatsapp:
            if msg.created_at:  # Only add if created_at is not None
                msg_body = msg.body or ""  # Use 'body' field, not 'message_body'
                
                # Look up the actual Lead ID from customer_id
                lead_id = None
                customer_id = getattr(msg, 'customer_id', None)
                if customer_id:
                    if customer_id not in customer_to_lead:
                        # BUILD 173: Handle Lead lookup errors gracefully
                        try:
                            lead = Lead.query.filter_by(tenant_id=tenant_id, customer_id=customer_id).first()
                            customer_to_lead[customer_id] = lead.id if lead else None
                        except Exception as lead_err:
                            logger.warning(f"Lead lookup failed for tenant={tenant_id}, customer={customer_id}: {lead_err}")
                            customer_to_lead[customer_id] = None
                    lead_id = customer_to_lead.get(customer_id)
                
                activities.append({
                    "ts": msg.created_at.isoformat() + "Z",
                    "type": "whatsapp",
                    "leadId": lead_id,
                    "preview": msg_body[:50] + "..." if len(msg_body) > 50 else msg_body,
                    "provider": getattr(msg, 'provider', "baileys")  # Default provider
                })
        
        # Add call activities (with None check for created_at)
        for call in recent_calls:
            if call.created_at:  # Only add if created_at is not None
                # Look up the actual Lead ID from customer_id
                lead_id = None
                customer_id = call.customer_id
                if customer_id:
                    if customer_id not in customer_to_lead:
                        # BUILD 173: Handle Lead lookup errors gracefully (reuse cached value)
                        try:
                            lead = Lead.query.filter_by(tenant_id=tenant_id, customer_id=customer_id).first()
                            customer_to_lead[customer_id] = lead.id if lead else None
                        except Exception as lead_err:
                            logger.warning(f"Lead lookup failed for call tenant={tenant_id}, customer={customer_id}: {lead_err}")
                            customer_to_lead[customer_id] = None
                    lead_id = customer_to_lead.get(customer_id)
                
                activities.append({
                    "ts": call.created_at.isoformat() + "Z",
                    "type": "call", 
                    "leadId": lead_id,
                    "preview": f"שיחה - {call.status}",
                    "provider": "twilio"
                })
        
        # Sort by timestamp and take top 20
        activities.sort(key=lambda x: x["ts"], reverse=True)
        activities = activities[:20]
        
        return jsonify({
            "items": activities
        })
        
    except Exception as e:
        logger.error(f"Error in dashboard_activity: {e}")
        return jsonify({"error": "internal_server_error"}), 500

# === ADMIN ENDPOINTS ===
# ✅ BUILD 155: Removed duplicate /api/admin/businesses - now handled by admin_bp in routes_admin.py

@api_adapter_bp.route('/api/admin/stats', methods=['GET'])
@require_api_auth(['admin', 'manager', 'system_admin', 'owner'])  # BUILD 137: Use proper decorator
def admin_stats():
    """Administrative KPIs - admin and manager only"""
    try:
        # Leads stats (using customers as leads)
        total_leads = Customer.query.count()
        
        today = datetime.utcnow().date()
        leads_today = Customer.query.filter(
            db.func.date(Customer.created_at) == today
        ).count()
        
        # Active leads (mock - customers with recent activity)
        active_leads = Customer.query.filter(
            Customer.created_at >= datetime.utcnow() - timedelta(days=30)
        ).count()
        
        # Users stats
        total_users = User.query.count()
        online_users = User.query.filter_by(is_active=True).count()  # Mock online as active
        
        # System stats (mock)
        uptime_sec = 86400  # 24 hours
        errors_24h = 2      # Mock error count
        
        return jsonify({
            "leads": {
                "total": total_leads,
                "newToday": leads_today,
                "active": active_leads
            },
            "users": {
                "total": total_users,
                "online": online_users
            },
            "system": {
                "uptimeSec": uptime_sec,
                "errors24h": errors_24h
            }
        })
        
    except Exception as e:
        logger.error(f"Error in admin_stats: {e}")
        return jsonify({"error": "internal_server_error"}), 500