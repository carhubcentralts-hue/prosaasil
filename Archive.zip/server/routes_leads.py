"""
Leads CRM API routes - Monday/HubSpot/Salesforce style
Modern lead management with Kanban board support, reminders, and activity tracking
"""
from flask import Blueprint, jsonify, request, session, g
from server.models_sql import Lead, LeadActivity, LeadReminder, LeadMergeCandidate, LeadNote, User, Business, CallLog
from server.db import db
from server.auth_api import require_api_auth
from datetime import datetime, timezone
from sqlalchemy import or_, and_, func, desc
from sqlalchemy.orm import joinedload
import logging

log = logging.getLogger(__name__)

leads_bp = Blueprint("leads_bp", __name__)

def normalize_source(source: str) -> str:
    """
    Normalize lead source to only 'phone' or 'whatsapp'
    All phone-related sources (call, realtime_phone, phone_call, etc.) become 'phone'
    All WhatsApp-related sources become 'whatsapp'
    """
    if not source:
        return 'phone'
    
    source_lower = source.lower().strip()
    
    phone_sources = {'call', 'phone', 'phone_call', 'realtime_phone', 'ai_agent', 'form', 'manual'}
    whatsapp_sources = {'whatsapp', 'wa', 'whats_app'}
    
    if source_lower in whatsapp_sources:
        return 'whatsapp'
    
    return 'phone'

def get_current_user():
    """
    BUILD 141 FIX: Get current user from g.user (populated by @require_api_auth)
    
    IMPORTANT: This relies on @require_api_auth decorator populating g.user
    """
    # Priority 1: Use g.user if available (set by @require_api_auth)
    if hasattr(g, 'user') and g.user:
        return g.user
    
    # Priority 2: Fallback to session - try both keys for compatibility
    return session.get('user') or session.get('al_user')

def get_current_tenant():
    """
    BUILD 143 FIX: Prioritize g.tenant (set by @require_api_auth) before session checks
    
    This ensures owner/admin/agent users get their tenant from the decorator,
    while system_admin can still use impersonation via session.
    """
    # Priority 1: Use g.tenant if available (set by @require_api_auth) - MOST RELIABLE
    if hasattr(g, 'tenant') and g.tenant:
        log.info(f"✅ get_current_tenant(): Using g.tenant={g.tenant}")
        return g.tenant
    
    # Priority 2: Check if impersonating (for system_admin)
    if session.get('impersonating') and session.get('impersonated_tenant_id'):
        tenant = session['impersonated_tenant_id']
        log.info(f"✅ get_current_tenant(): Impersonating tenant_id={tenant}")
        return tenant
    
    # Priority 3: Fallback to impersonated session WITHOUT flag (backward compat)
    impersonated_id = session.get('impersonated_tenant_id')
    if impersonated_id:
        log.info(f"✅ get_current_tenant(): Using impersonated_tenant_id={impersonated_id}")
        return impersonated_id
    
    # Priority 4: Get from user session - try both session keys
    user = session.get('user') or session.get('al_user')
    if user and user.get('business_id'):
        log.info(f"✅ get_current_tenant(): Using user.business_id={user.get('business_id')}")
        return user.get('business_id')
    
    # No tenant found - OK for system_admin, error for others
    user_role = user.get('role') if user else None
    if user_role == 'system_admin':
        log.info(f"✅ get_current_tenant(): system_admin with no tenant (OK)")
        return None
    
    log.error(f"❌ get_current_tenant(): No tenant found! g.tenant={getattr(g, 'tenant', None)}, impersonated={impersonated_id}, user={user}")
    return None

def require_auth():
    """
    BUILD 136 DEPRECATED: Use @require_api_auth() decorator instead
    
    This function is kept for backward compatibility but should not be used
    in new code. Use @require_api_auth() which properly sets g.user and g.tenant
    """
    user = get_current_user()
    if not user:
        return jsonify({"error": "Authentication required"}), 401
    return None

def check_lead_access(lead_id):
    """Check if current user can access lead"""
    user = get_current_user()
    if not user:
        return False
    
    # ✅ FIX: system_admin can access ALL leads
    if user.get('role') == 'system_admin':
        lead = Lead.query.filter_by(id=lead_id).first()
        return lead is not None
    
    # Business-level roles (owner, admin, agent): check tenant
    tenant_id = get_current_tenant()
    if not tenant_id:
        return False
    
    lead = Lead.query.filter_by(id=lead_id, tenant_id=tenant_id).first()
    return lead is not None

def create_activity(lead_id, activity_type, payload, created_by=None):
    """Helper to create lead activity record"""
    activity = LeadActivity()
    activity.lead_id = lead_id
    activity.type = activity_type
    activity.payload = payload
    activity.created_by = created_by
    activity.at = datetime.utcnow()
    db.session.add(activity)

def ensure_default_statuses_exist(business_id):
    """Ensure default statuses exist for business - shared seeding logic"""
    from server.models_sql import LeadStatus
    
    # Check if statuses already exist
    existing_statuses = LeadStatus.query.filter_by(
        business_id=business_id,
        is_active=True
    ).count()
    
    if existing_statuses > 0:
        return  # Already seeded
    
    # Default Hebrew real estate statuses - ALWAYS lowercase canonical names
    default_statuses = [
        {'name': 'new', 'label': 'חדש', 'color': 'bg-blue-100 text-blue-800', 'is_default': True},
        {'name': 'attempting', 'label': 'בניסיון קשר', 'color': 'bg-yellow-100 text-yellow-800'},
        {'name': 'contacted', 'label': 'נוצר קשר', 'color': 'bg-purple-100 text-purple-800'},
        {'name': 'qualified', 'label': 'מוכשר', 'color': 'bg-green-100 text-green-800'},
        {'name': 'won', 'label': 'זכיה', 'color': 'bg-emerald-100 text-emerald-800', 'is_system': True},
        {'name': 'lost', 'label': 'אובדן', 'color': 'bg-red-100 text-red-800', 'is_system': True},
        {'name': 'unqualified', 'label': 'לא מוכשר', 'color': 'bg-gray-100 text-gray-800', 'is_system': True}
    ]
    
    for index, status_data in enumerate(default_statuses):
        status = LeadStatus()
        status.business_id = business_id
        status.name = status_data['name']  # Already lowercase canonical
        status.label = status_data['label']
        status.color = status_data['color']
        status.order_index = index
        status.is_default = status_data.get('is_default', False)
        status.is_system = status_data.get('is_system', False)
        db.session.add(status)
    
    db.session.commit()

def get_default_status_for_business(business_id):
    """Get default status for business with fallback to 'new'"""
    from server.models_sql import LeadStatus
    
    # Ensure default statuses exist first
    ensure_default_statuses_exist(business_id)
    
    # Get the default status
    default_status = LeadStatus.query.filter_by(
        business_id=business_id,
        is_active=True,
        is_default=True
    ).first()
    
    if default_status:
        return default_status.name  # Return canonical lowercase name
    
    # Fallback: if no default found, return 'new' (should not happen after seeding)
    log.warning(f"No default status found for business {business_id}, using fallback 'new'")
    return 'new'

def get_valid_statuses_for_business(business_id):
    """Get valid statuses for business, with guaranteed seeding"""
    from server.models_sql import LeadStatus
    
    # Ensure default statuses exist first
    ensure_default_statuses_exist(business_id)
    
    # Get statuses (guaranteed to exist now)
    statuses = LeadStatus.query.filter_by(
        business_id=business_id,
        is_active=True
    ).all()
    
    return [s.name for s in statuses]  # Return canonical lowercase names

# === LEAD MANAGEMENT ENDPOINTS ===

@leads_bp.route("/api/leads", methods=["GET"])
@require_api_auth()
def list_leads():
    """List leads with filtering and pagination"""
    
    user = get_current_user()
    is_system_admin = user.get('role') == 'system_admin' if user else False
    
    # BUILD 135: ONLY system_admin can see ALL leads
    if is_system_admin:
        # System admin sees all leads across all businesses
        query = Lead.query
    else:
        # BUILD 135: owner/admin/agent see only their tenant's leads
        tenant_id = get_current_tenant()
        if not tenant_id:
            return jsonify({"error": "No tenant access"}), 403
        query = Lead.query.filter_by(tenant_id=tenant_id)
    
    # Parse query parameters
    status_filter = request.args.get('status', '')
    source_filter = request.args.get('source', '')
    owner_filter = request.args.get('owner', '')
    q_filter = request.args.get('q', '')  # Search query
    from_date = request.args.get('from', '')
    to_date = request.args.get('to', '')
    page = int(request.args.get('page', 1))
    page_size = min(int(request.args.get('pageSize', 50)), 100)  # Max 100 per page
    
    # Apply filters
    if status_filter:
        # ✅ FIXED: Case-insensitive status filtering for legacy compatibility
        query = query.filter(func.lower(Lead.status) == status_filter.lower())
    
    if source_filter:
        if source_filter == 'phone':
            phone_sources = ['call', 'phone', 'phone_call', 'realtime_phone', 'ai_agent', 'form', 'manual']
            query = query.filter(Lead.source.in_(phone_sources))
        elif source_filter == 'whatsapp':
            whatsapp_sources = ['whatsapp', 'wa', 'whats_app']
            query = query.filter(Lead.source.in_(whatsapp_sources))
    
    if owner_filter:
        query = query.filter(Lead.owner_user_id == owner_filter)
    
    if q_filter:
        # ✅ BUILD 170: Search only by name or phone number (partial match)
        # Remove email from search, phone partial match works (e.g., "075" finds any number containing "075")
        search_term = f"%{q_filter}%"
        query = query.filter(
            or_(
                Lead.first_name.ilike(search_term),
                Lead.last_name.ilike(search_term),
                Lead.phone_e164.ilike(search_term)
            )
        )
    
    if from_date:
        try:
            from_dt = datetime.fromisoformat(from_date.replace('Z', '+00:00'))
            query = query.filter(Lead.created_at >= from_dt)
        except ValueError:
            pass
    
    if to_date:
        try:
            to_dt = datetime.fromisoformat(to_date.replace('Z', '+00:00'))
            query = query.filter(Lead.created_at <= to_dt)
        except ValueError:
            pass
    
    # Order by created_at DESC for faster sorting (indexed column)
    # BUILD 174: Performance optimization - avoid ORDER BY on multiple columns
    query = query.order_by(Lead.created_at.desc())
    
    # Pagination - BUILD 174: Optimize count query
    offset = (page - 1) * page_size
    
    # Use a lighter count query - only count IDs (faster)
    count_query = query.with_entities(Lead.id)
    total = count_query.count()
    
    # Fetch leads with pagination
    leads = query.offset(offset).limit(page_size).all()
    
    # Format response
    items = []
    for lead in leads:
        items.append({
            "id": lead.id,
            "first_name": lead.first_name,
            "last_name": lead.last_name,
            "full_name": lead.full_name,
            "phone_e164": lead.phone_e164,
            "display_phone": lead.display_phone,
            "email": lead.email,
            "status": lead.status,
            "source": normalize_source(lead.source),
            "owner_user_id": lead.owner_user_id,
            "tags": lead.tags or [],
            "created_at": lead.created_at.isoformat() if lead.created_at else None,
            "updated_at": lead.updated_at.isoformat() if lead.updated_at else None,
            "last_contact_at": lead.last_contact_at.isoformat() if lead.last_contact_at else None
        })
    
    return jsonify({
        "items": items,
        "total": total,
        "page": page,
        "pageSize": page_size,
        "totalPages": (total + page_size - 1) // page_size
    })

@leads_bp.route("/api/leads", methods=["POST"])
@require_api_auth()  # BUILD 137: Use proper decorator that sets g.user and g.tenant
def create_lead():
    """Create new lead manually"""
    try:
        log.info(f"🔵 CREATE LEAD - Starting request")
        
        tenant_id = get_current_tenant()
        log.info(f"🔵 CREATE LEAD - tenant_id: {tenant_id}")
        if not tenant_id:
            log.error(f"🔴 CREATE LEAD - No tenant access")
            return jsonify({"error": "No tenant access"}), 403
        
        data = request.get_json()
        log.info(f"🔵 CREATE LEAD - Received data: {data}")
        if not data:
            log.error(f"🔴 CREATE LEAD - No JSON data")
            return jsonify({"error": "JSON data required"}), 400
        
        # Validate required fields
        if not data.get('first_name') and not data.get('phone_e164'):
            log.error(f"🔴 CREATE LEAD - Missing required fields")
            return jsonify({"error": "Either first_name or phone_e164 is required"}), 400
        
        # Check for duplicates if phone provided - UPDATE instead of error
        if data.get('phone_e164'):
            existing = Lead.query.filter_by(
                tenant_id=tenant_id,
                phone_e164=data['phone_e164']
            ).first()
            if existing:
                log.info(f"🟡 CREATE LEAD - Found existing lead with phone {data['phone_e164']}, updating instead")
                
                # Update existing lead with new data
                if data.get('first_name'):
                    existing.first_name = data['first_name']
                if data.get('last_name'):
                    existing.last_name = data['last_name']
                if data.get('email'):
                    existing.email = data['email']
                if data.get('notes'):
                    # Append new notes to existing ones
                    if existing.notes:
                        existing.notes = existing.notes + "\n\n---\n\n" + data['notes']
                    else:
                        existing.notes = data['notes']
                
                # Update status if provided and valid
                if data.get('status'):
                    valid_statuses = get_valid_statuses_for_business(tenant_id)
                    normalized_status = data['status'].lower().strip()
                    if normalized_status in valid_statuses:
                        existing.status = normalized_status
                
                # Update tags if provided
                if data.get('tags'):
                    existing.tags = list(set((existing.tags or []) + data['tags']))
                
                existing.updated_at = datetime.utcnow()
                
                # Create activity for update
                user = get_current_user()
                create_activity(
                    existing.id,
                    "lead_updated",
                    {
                        "method": "duplicate_prevention",
                        "updated_by": user.get('email', 'unknown') if user else 'unknown',
                        "fields_updated": [k for k in ['first_name', 'last_name', 'email', 'notes', 'status', 'tags'] if data.get(k)]
                    },
                    user.get('id') if user else None
                )
                
                db.session.commit()
                log.info(f"✅ CREATE LEAD - Updated existing lead ID: {existing.id}")
                
                return jsonify({
                    "lead": {
                        "id": existing.id,
                        "first_name": existing.first_name,
                        "last_name": existing.last_name,
                        "full_name": existing.full_name,
                        "phone_e164": existing.phone_e164,
                        "email": existing.email,
                        "status": existing.status,
                        "source": existing.source,
                        "created_at": existing.created_at.isoformat(),
                        "updated_at": existing.updated_at.isoformat() if existing.updated_at else None
                    },
                    "updated": True
                }), 200
        
        # Create new lead
        user = get_current_user()
        log.info(f"🔵 CREATE LEAD - User: {user.get('email') if user else 'None'}")
        
        # ✅ FIXED: Use actual default status from database, not hardcoded 'new'
        log.info(f"🔵 CREATE LEAD - Getting valid statuses for tenant {tenant_id}")
        valid_statuses = get_valid_statuses_for_business(tenant_id)
        log.info(f"🔵 CREATE LEAD - Valid statuses: {valid_statuses}")
        
        default_status = get_default_status_for_business(tenant_id)  # Get actual default from DB
        log.info(f"🔵 CREATE LEAD - Default status: {default_status}")
        
        # Normalize provided status to canonical lowercase
        provided_status = data.get('status')
        if provided_status:
            normalized_status = provided_status.lower().strip()
            if normalized_status in valid_statuses:
                default_status = normalized_status
            else:
                log.error(f"🔴 CREATE LEAD - Invalid status: {provided_status}")
                return jsonify({
                    "error": f"Invalid status '{provided_status}'. Valid options: {', '.join(valid_statuses)}"
                }), 400
        
        log.info(f"🔵 CREATE LEAD - Creating lead object")
        lead = Lead()
        lead.tenant_id = tenant_id
        lead.first_name = data.get('first_name')
        lead.last_name = data.get('last_name')
        lead.phone_e164 = data.get('phone_e164')
        lead.email = data.get('email')
        lead.source = data.get('source', 'manual')
        lead.status = default_status  # Always canonical lowercase
        lead.owner_user_id = data.get('owner_user_id') or (user.get('id') if user else None)
        lead.tags = data.get('tags', [])
        lead.notes = data.get('notes')
        
        log.info(f"🔵 CREATE LEAD - Adding to session")
        db.session.add(lead)
        db.session.flush()  # Get ID
        log.info(f"🔵 CREATE LEAD - Lead ID: {lead.id}")
        
        # Create activity
        log.info(f"🔵 CREATE LEAD - Creating activity")
        create_activity(
            lead.id,
            "lead_created",
            {
                "method": "manual",
                "created_by": user.get('email', 'unknown') if user else 'unknown'
            },
            user.get('id') if user else None
        )
        
        log.info(f"🔵 CREATE LEAD - Committing to DB")
        db.session.commit()
        
        log.info(f"✅ CREATE LEAD - Success! Lead ID: {lead.id}")
        # ✅ FIX: Return lead wrapped in {lead: {...}} to match frontend expectations
        return jsonify({
            "lead": {
                "id": lead.id,
                "first_name": lead.first_name,
                "last_name": lead.last_name,
                "full_name": lead.full_name,
                "phone_e164": lead.phone_e164,
                "email": lead.email,
                "status": lead.status,
                "source": normalize_source(lead.source),
                "created_at": lead.created_at.isoformat()
            }
        }), 201
        
    except Exception as e:
        db.session.rollback()
        log.error(f"🔴 CREATE LEAD - Exception: {e}")
        import traceback
        log.error(f"🔴 CREATE LEAD - Traceback: {traceback.format_exc()}")
        return jsonify({"error": f"Failed to create lead: {str(e)}"}), 500

@leads_bp.route("/api/leads/<int:lead_id>", methods=["GET"])
@require_api_auth()  # BUILD 137: Added missing decorator
def get_lead_detail(lead_id):
    """Get detailed lead information with activities and reminders"""
    try:
        # BUILD 137: Authentication handled by @require_api_auth() decorator
        
        if not check_lead_access(lead_id):
            return jsonify({"error": "Lead not found or access denied"}), 404
        
        # Get lead with related data
        lead = Lead.query.filter_by(id=lead_id).first()
        if not lead:
            return jsonify({"error": "Lead not found"}), 404
        
        # Get reminders
        reminders = LeadReminder.query.filter_by(lead_id=lead_id).order_by(LeadReminder.due_at).all()
        
        # Get recent activities
        activities = LeadActivity.query.filter_by(lead_id=lead_id).order_by(desc(LeadActivity.at)).limit(50).all()
        
        # Format reminders safely
        formatted_reminders = []
        for r in reminders:
            try:
                formatted_reminders.append({
                    "id": r.id,
                    "due_at": r.due_at.isoformat() if r.due_at else None,
                    "note": r.note,
                    "channel": r.channel,
                    "delivered_at": r.delivered_at.isoformat() if r.delivered_at else None,
                    "completed_at": r.completed_at.isoformat() if r.completed_at else None
                })
            except Exception as e:
                log.error(f"Error formatting reminder {r.id}: {e}")
                continue
        
        # Format activities safely
        formatted_activities = []
        for a in activities:
            try:
                formatted_activities.append({
                    "id": a.id,
                    "type": a.type,
                    "payload": a.payload if a.payload is not None else {},
                    "at": a.at.isoformat() if a.at else None,
                    "created_by": a.created_by
                })
            except Exception as e:
                log.error(f"Error formatting activity {a.id}: {e}")
                continue
        
        # Format response
        response = {
            "id": lead.id,
            "first_name": lead.first_name,
            "last_name": lead.last_name,
            "full_name": lead.full_name,
            "phone_e164": lead.phone_e164,
            "display_phone": lead.display_phone,
            "email": lead.email,
            "status": lead.status,
            "source": normalize_source(lead.source),
            "external_id": lead.external_id,
            "owner_user_id": lead.owner_user_id,
            "tags": lead.tags or [],
            "notes": lead.notes,
            "created_at": lead.created_at.isoformat() if lead.created_at else None,
            "updated_at": lead.updated_at.isoformat() if lead.updated_at else None,
            "last_contact_at": lead.last_contact_at.isoformat() if lead.last_contact_at else None,
            "tenant_id": lead.tenant_id,
            
            "reminders": formatted_reminders,
            "activity": formatted_activities
        }
        
        return jsonify(response)
    except Exception as e:
        log.error(f"Error getting lead detail for lead {lead_id}: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"error": "Internal server error", "details": str(e)}), 500

@leads_bp.route("/api/leads/<int:lead_id>", methods=["PATCH"])
@require_api_auth()  # BUILD 137: Added missing decorator
def update_lead(lead_id):
    """Update lead information"""
    # BUILD 137: Authentication handled by @require_api_auth() decorator
    
    if not check_lead_access(lead_id):
        return jsonify({"error": "Lead not found or access denied"}), 404
    
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON data required"}), 400
    
    lead = Lead.query.filter_by(id=lead_id).first()
    if not lead:
        return jsonify({"error": "Lead not found"}), 404
        
    user = get_current_user()
    
    # Track changes for activity log
    changes = {}
    
    # Update allowed fields
    updateable_fields = ['first_name', 'last_name', 'phone_e164', 'email', 'owner_user_id', 'tags', 'notes']
    
    for field in updateable_fields:
        if field in data:
            old_value = getattr(lead, field)
            new_value = data[field]
            if old_value != new_value:
                changes[field] = {"from": old_value, "to": new_value}
                setattr(lead, field, new_value)
    
    # Update timestamp
    lead.updated_at = datetime.utcnow()
    
    # Log changes
    if changes:
        create_activity(
            lead_id,
            "lead_updated",
            {
                "changes": changes,
                "updated_by": user.get('email', 'unknown') if user else 'unknown'
            },
            user.get('id') if user else None
        )
    
    db.session.commit()
    
    # ✅ FIX: Return the updated lead object so frontend can update UI
    return jsonify({
        "message": "Lead updated successfully", 
        "changes": changes,
        "lead": {
            "id": lead.id,
            "first_name": lead.first_name,
            "last_name": lead.last_name,
            "phone_e164": lead.phone_e164,
            "email": lead.email,
            "status": lead.status,
            "source": normalize_source(lead.source),
            "owner_user_id": lead.owner_user_id,
            "tags": lead.tags,
            "notes": lead.notes,
            "summary": lead.summary,
            "created_at": lead.created_at.isoformat() if lead.created_at else None,
            "updated_at": lead.updated_at.isoformat() if lead.updated_at else None
        }
    })

@leads_bp.route("/api/leads/<int:lead_id>", methods=["DELETE"])
@require_api_auth()  # BUILD 137: Added missing decorator
def delete_lead(lead_id):
    """Delete a lead"""
    # BUILD 137: Authentication handled by @require_api_auth() decorator
    
    user = get_current_user()
    if not user:
        return jsonify({"error": "Authentication required"}), 401
    
    # ✅ Admin/Superadmin can delete any lead across tenants
    is_admin = user.get('role') in ['admin', 'superadmin']
    
    # Check access - admin can access all, regular users need tenant match
    if not is_admin and not check_lead_access(lead_id):
        return jsonify({"error": "Lead not found or access denied"}), 404
    
    lead = Lead.query.filter_by(id=lead_id).first()
    if not lead:
        return jsonify({"error": "Lead not found"}), 404
    
    # Delete related activities and reminders first (cascade)
    LeadActivity.query.filter_by(lead_id=lead_id).delete()
    LeadReminder.query.filter_by(lead_id=lead_id).delete()
    
    # Delete the lead
    db.session.delete(lead)
    db.session.commit()
    
    log.info(f"✅ Lead {lead_id} deleted by {user.get('role')} user {user.get('email')}")
    
    return jsonify({"message": "Lead deleted successfully"}), 200

@leads_bp.route("/api/leads/<int:lead_id>/status", methods=["POST"])
@require_api_auth()  # BUILD 137: Added missing decorator
def update_lead_status(lead_id):
    """Update lead status (for Kanban board)"""
    # BUILD 137: Authentication handled by @require_api_auth() decorator
    
    if not check_lead_access(lead_id):
        return jsonify({"error": "Lead not found or access denied"}), 404
    
    data = request.get_json()
    if not data or 'status' not in data:
        return jsonify({"error": "Status is required"}), 400
    
    new_status = data['status']
    
    lead = Lead.query.filter_by(id=lead_id).first()
    if not lead:
        return jsonify({"error": "Lead not found"}), 404
    
    # ✅ FIXED: Get valid statuses with guaranteed seeding - no more race condition
    valid_statuses = get_valid_statuses_for_business(lead.tenant_id)
    
    # ✅ FIXED: Always normalize to canonical lowercase - no more TitleCase writes
    original_status = new_status
    normalized_status = new_status.lower().strip()
    
    # Find exact match in valid statuses (all are lowercase canonical)
    if normalized_status not in valid_statuses:
        return jsonify({
            "error": f"Invalid status '{original_status}'. Valid options: {', '.join(valid_statuses)}"
        }), 400
    
    # Always use the canonical lowercase name
    new_status = normalized_status
        
    old_status = lead.status
    
    if old_status != new_status:
        lead.status = new_status
        lead.updated_at = datetime.utcnow()
        
        # Log status change
        user = get_current_user()
        create_activity(
            lead_id,
            "status_change",
            {
                "from": old_status,
                "to": new_status,
                "changed_by": user.get('email', 'unknown') if user else 'unknown'
            },
            user.get('id') if user else None
        )
        
        db.session.commit()
        
        return jsonify({"message": "Status updated successfully", "old_status": old_status, "new_status": new_status})
    
    return jsonify({"message": "Status unchanged"})

@leads_bp.route("/api/leads/<int:lead_id>/reminders", methods=["GET"])
@require_api_auth()  # BUILD 137: Added missing decorator
def get_lead_reminders(lead_id):
    """Get all reminders for a lead"""
    # BUILD 137: Authentication handled by @require_api_auth() decorator
    
    if not check_lead_access(lead_id):
        return jsonify({"error": "Lead not found or access denied"}), 404
    
    reminders = LeadReminder.query.filter_by(lead_id=lead_id).order_by(LeadReminder.due_at.desc()).all()
    
    return jsonify({
        "reminders": [
            {
                "id": r.id,
                "lead_id": r.lead_id,
                "due_at": r.due_at.isoformat() if r.due_at else None,
                "note": r.note,
                "channel": r.channel,
                "completed_at": r.completed_at.isoformat() if r.completed_at else None,
                "created_by": r.created_by
            }
            for r in reminders
        ]
    })

@leads_bp.route("/api/leads/<int:lead_id>/activities", methods=["GET"])
@require_api_auth()  # BUILD 137: Added missing decorator
def get_lead_activities(lead_id):
    """Get all activities for a lead"""
    # BUILD 137: Authentication handled by @require_api_auth() decorator
    
    if not check_lead_access(lead_id):
        return jsonify({"error": "Lead not found or access denied"}), 404
    
    activities = LeadActivity.query.filter_by(lead_id=lead_id).order_by(LeadActivity.at.desc()).all()
    
    return jsonify({
        "activities": [
            {
                "id": a.id,
                "lead_id": a.lead_id,
                "type": a.type,
                "at": a.at.isoformat() if a.at else None,
                "payload": a.payload,
                "user_id": a.user_id
            }
            for a in activities
        ]
    })

@leads_bp.route("/api/leads/<int:lead_id>/reminders", methods=["POST"])
@require_api_auth()  # BUILD 137: Added missing decorator
def create_reminder(lead_id):
    """Create 'חזור אליי' reminder"""
    # BUILD 137: Authentication handled by @require_api_auth() decorator
    
    if not check_lead_access(lead_id):
        return jsonify({"error": "Lead not found or access denied"}), 404
    
    data = request.get_json()
    if not data or 'due_at' not in data:
        return jsonify({"error": "due_at is required"}), 400
    
    try:
        due_at = datetime.fromisoformat(data['due_at'].replace('Z', '+00:00'))
    except ValueError:
        return jsonify({"error": "Invalid due_at format. Use ISO format"}), 400
    
    user = get_current_user()
    tenant_id = get_current_tenant()
    
    reminder = LeadReminder()
    reminder.tenant_id = tenant_id  # Required for new schema
    reminder.lead_id = lead_id
    reminder.due_at = due_at
    reminder.note = data.get('note')
    reminder.channel = data.get('channel', 'ui')
    reminder.created_by = user.get('id') if user else None
    
    db.session.add(reminder)
    
    # Log reminder creation
    create_activity(
        lead_id,
        "reminder_created",
        {
            "due_at": due_at.isoformat(),
            "note": data.get('note'),
            "channel": data.get('channel', 'ui'),
            "created_by": user.get('email', 'unknown') if user else 'unknown'
        },
        user.get('id') if user else None
    )
    
    db.session.commit()
    
    return jsonify({
        "id": reminder.id,
        "due_at": reminder.due_at.isoformat(),
        "note": reminder.note,
        "channel": reminder.channel,
        "message": "Reminder created successfully"
    }), 201

# === ADMIN ENDPOINTS ===
# Note: Admin leads endpoint moved to routes_admin.py to avoid duplicate route conflict
# REMOVED: Duplicate /api/admin/leads route was here - now only in routes_admin.py

@leads_bp.route("/api/leads/<int:lead_id>/move", methods=["PATCH"])
@require_api_auth()  # BUILD 137: Added missing decorator
def move_lead_in_kanban(lead_id):
    """Move lead position in Kanban board (drag & drop support)"""
    # BUILD 137: Authentication handled by @require_api_auth() decorator
    
    if not check_lead_access(lead_id):
        return jsonify({"error": "Lead not found or access denied"}), 404
    
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON data required"}), 400
    
    # Extract move parameters
    new_status = data.get('status')
    before_id = data.get('beforeId')  # ID of lead before which to place this lead
    after_id = data.get('afterId')    # ID of lead after which to place this lead
    
    tenant_id = get_current_tenant()
    lead = Lead.query.filter_by(id=lead_id, tenant_id=tenant_id).first()
    if not lead:
        return jsonify({"error": "Lead not found"}), 404
    
    # Update status if provided
    if new_status and new_status != lead.status:
        # ✅ FIXED: Use guaranteed seeding and canonical lowercase validation
        valid_statuses = get_valid_statuses_for_business(tenant_id)
        normalized_status = new_status.lower().strip()
        
        if normalized_status not in valid_statuses:
            return jsonify({"error": f"Invalid status '{new_status}'. Valid options: {', '.join(valid_statuses)}"}), 400
        
        old_status = lead.status
        lead.status = normalized_status  # Always canonical lowercase
        
        # Log status change
        user = get_current_user()
        create_activity(
            lead_id,
            "kanban_move",
            {
                "from_status": old_status,
                "to_status": new_status,
                "moved_by": user.get('email', 'unknown') if user else 'unknown'
            },
            user.get('id') if user else None
        )
    
    # Calculate new order_index based on before/after positioning
    new_order_index = 0
    
    if before_id or after_id:
        # Get reference leads for positioning
        if before_id:
            before_lead = Lead.query.filter_by(id=before_id, tenant_id=tenant_id).first()
            if before_lead and before_lead.status == (new_status or lead.status):
                new_order_index = before_lead.order_index - 1
        
        if after_id:
            after_lead = Lead.query.filter_by(id=after_id, tenant_id=tenant_id).first()
            if after_lead and after_lead.status == (new_status or lead.status):
                new_order_index = max(new_order_index, after_lead.order_index + 1)
    
    # If no positioning specified, put at the end of the status column
    if new_order_index == 0:
        last_lead = Lead.query.filter_by(
            tenant_id=tenant_id, 
            status=(new_status or lead.status)
        ).order_by(desc(Lead.order_index)).first()
        new_order_index = (last_lead.order_index + 100) if last_lead else 100
    
    lead.order_index = new_order_index
    lead.updated_at = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({
        "message": "Lead moved successfully",
        "status": lead.status,
        "order_index": lead.order_index
    })

@leads_bp.route("/api/leads/<int:lead_id>/reminders/<int:reminder_id>", methods=["GET"])
@require_api_auth()  # BUILD 137: Added missing decorator
def get_reminder(lead_id, reminder_id):
    """Get specific reminder details"""
    # BUILD 137: Authentication handled by @require_api_auth() decorator
    
    if not check_lead_access(lead_id):
        return jsonify({"error": "Lead not found or access denied"}), 404
    
    reminder = LeadReminder.query.filter_by(id=reminder_id, lead_id=lead_id).first()
    if not reminder:
        return jsonify({"error": "Reminder not found"}), 404
    
    return jsonify({
        "id": reminder.id,
        "due_at": reminder.due_at.isoformat() if reminder.due_at else None,
        "note": reminder.note,
        "channel": reminder.channel,
        "delivered_at": reminder.delivered_at.isoformat() if reminder.delivered_at else None,
        "completed_at": reminder.completed_at.isoformat() if reminder.completed_at else None,
        "created_at": reminder.created_at.isoformat() if reminder.created_at else None
    })

@leads_bp.route("/api/leads/<int:lead_id>/reminders/<int:reminder_id>", methods=["PATCH"])
@require_api_auth()  # BUILD 137: Added missing decorator
def update_reminder(lead_id, reminder_id):
    """Update or complete reminder"""
    # BUILD 137: Authentication handled by @require_api_auth() decorator
    
    if not check_lead_access(lead_id):
        return jsonify({"error": "Lead not found or access denied"}), 404
    
    reminder = LeadReminder.query.filter_by(id=reminder_id, lead_id=lead_id).first()
    if not reminder:
        return jsonify({"error": "Reminder not found"}), 404
    
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON data required"}), 400
    
    # Update allowed fields
    if 'due_at' in data:
        try:
            reminder.due_at = datetime.fromisoformat(data['due_at'].replace('Z', '+00:00'))
        except ValueError:
            return jsonify({"error": "Invalid due_at format. Use ISO format"}), 400
    
    if 'note' in data:
        reminder.note = data['note']
    
    if 'completed' in data and data['completed']:
        reminder.completed_at = datetime.utcnow()
        
        # Log completion
        user = get_current_user()
        create_activity(
            lead_id,
            "reminder_completed",
            {
                "reminder_id": reminder_id,
                "note": reminder.note,
                "completed_by": user.get('email', 'unknown') if user else 'unknown'
            },
            user.get('id') if user else None
        )
    
    db.session.commit()
    
    return jsonify({"message": "Reminder updated successfully"})


@leads_bp.route("/api/reminders/due", methods=["GET"])
@require_api_auth()  # BUILD 137: Added missing decorator
def get_due_reminders():
    """Get all due and overdue reminders for notifications"""
    
    # Use existing auth pattern
    # BUILD 137: Authentication handled by @require_api_auth() decorator
    
    tenant_id = get_current_tenant()
    if not tenant_id:
        return jsonify({"error": "No tenant access"}), 403

    # Get current time and filter due reminders
    now = datetime.utcnow()
    
    # Query for due reminders (not completed, due time has passed)
    # Use left join to support reminders without lead_id
    due_reminders = db.session.query(LeadReminder, Lead).outerjoin(
        Lead, LeadReminder.lead_id == Lead.id
    ).filter(
        LeadReminder.tenant_id == tenant_id,  # Business scope via direct tenant ownership
        LeadReminder.completed_at.is_(None),  # Not completed
        LeadReminder.due_at <= now  # Due or overdue
    ).order_by(LeadReminder.due_at.asc()).all()

    # Build response with lead context
    reminders_data = []
    for reminder, lead in due_reminders:
        reminders_data.append({
            "id": reminder.id,
            "lead_id": reminder.lead_id,
            "lead_name": lead.full_name if lead else None,
            "lead_phone": lead.display_phone if lead else None,
            "due_at": reminder.due_at.isoformat(),
            "note": reminder.note,
            "channel": reminder.channel,
            "overdue_minutes": int((now - reminder.due_at).total_seconds() / 60) if reminder.due_at < now else 0,
            "created_at": reminder.created_at.isoformat()
        })

    return jsonify({
        "reminders": reminders_data,
        "total_count": len(reminders_data),
        "overdue_count": len([r for r in reminders_data if r["overdue_minutes"] > 0])
    })

@leads_bp.route("/api/notifications", methods=["GET"])
@require_api_auth()  # BUILD 142 FINAL FIX
def get_notifications():
    """Get task notifications categorized by urgency (overdue, today, soon)"""
    try:
        tenant_id = get_current_tenant()
        print(f"🔔 /api/notifications - tenant_id={tenant_id}, g.tenant={getattr(g, 'tenant', None)}")
        
        # BUILD 142 FINAL: system_admin (no tenant) should see ALL notifications
        user = get_current_user()
        is_system_admin = user.get('role') == 'system_admin' if user else False
        
        # If no tenant and NOT system_admin, return empty
        if not tenant_id and not is_system_admin:
            print(f"⚠️ Non-admin user with no tenant - returning empty notifications")
            return jsonify({
                "notifications": [],
                "overdue": [],
                "today": [],
                "soon": []
            })
        
        # system_admin with no tenant sees ALL reminders across all businesses
        if is_system_admin and not tenant_id:
            print(f"✅ system_admin viewing ALL notifications (no tenant filter)")
            # Continue without tenant filter
        
        from datetime import timedelta
        from sqlalchemy import and_, cast, Date
        
        now = datetime.utcnow()
        today = now.date()
        soon_threshold = now + timedelta(hours=3)
        
        # BUILD 142 FINAL: Use tenant_id consistently (no business_id!)
        # Get all incomplete reminders for this business (or ALL for system_admin)
        print(f"🔔 Querying reminders for tenant_id={tenant_id}, is_system_admin={is_system_admin}")
        
        query = db.session.query(LeadReminder, Lead).outerjoin(
            Lead, LeadReminder.lead_id == Lead.id
        ).filter(
            LeadReminder.completed_at.is_(None)
        )
        
        # Add tenant filter ONLY if not system_admin
        if tenant_id:
            query = query.filter(LeadReminder.tenant_id == tenant_id)
        
        reminders = query.all()
        
        print(f"🔔 Found {len(reminders)} reminders")
    
    except Exception as e:
        import traceback
        print(f"❌ ERROR in /api/notifications: {e}")
        print(f"❌ STACKTRACE:\n{traceback.format_exc()}")
        return jsonify({"error": f"Internal error: {str(e)}"}), 500
    
    notifications = []
    
    for reminder, lead in reminders:
        # Categorize by date
        category = None
        if reminder.due_at < now:
            category = "overdue"
        elif reminder.due_at.date() == today:
            category = "today"
        elif reminder.due_at <= soon_threshold:
            category = "soon"
        else:
            # Skip future tasks (beyond 3 hours)
            continue
        
        notifications.append({
            "id": str(reminder.id),
            "title": reminder.note or "משימה ללא תיאור",
            "description": reminder.description,  # BUILD 151: For system notifications
            "due_date": reminder.due_at.isoformat(),
            "category": category,
            "phone": lead.display_phone if lead else None,
            "lead_id": reminder.lead_id,
            "lead_name": lead.full_name if lead else None,
            "created_at": reminder.created_at.isoformat() if reminder.created_at else None,
            "reminder_type": reminder.reminder_type,  # BUILD 151: For system notifications
            "priority": reminder.priority  # BUILD 151: For urgency indication
        })
    
    return jsonify({
        "success": True,
        "notifications": notifications,
        "count": len(notifications)
    })

@leads_bp.route("/api/leads/bulk-delete", methods=["POST"])
@require_api_auth()  # BUILD 137: Added missing decorator
def bulk_delete_leads():
    """Bulk delete multiple leads - with proper cascade cleanup"""
    # BUILD 137: Authentication handled by @require_api_auth() decorator
    
    user = get_current_user()
    is_system_admin = user.get('role') == 'system_admin' if user else False
    
    # BUILD 157: Always get tenant from session/g - even system_admin uses it when impersonating
    tenant_id = get_current_tenant()
    
    # BUILD 157: For non-system-admin, tenant is required
    if not is_system_admin and not tenant_id:
        return jsonify({"error": "No tenant access"}), 403
    
    data = request.get_json()
    if not data or 'lead_ids' not in data:
        return jsonify({"error": "lead_ids is required"}), 400
    
    lead_ids = data['lead_ids']
    
    if not isinstance(lead_ids, list) or len(lead_ids) == 0:
        return jsonify({"error": "lead_ids must be a non-empty array"}), 400
    
    log.info(f"🗑️ Bulk delete: user={user.get('email') if user else 'unknown'}, is_system_admin={is_system_admin}, tenant_id={tenant_id}, lead_ids={lead_ids}")
    
    try:
        # BUILD 157: Find leads - use tenant filtering when available
        if tenant_id:
            leads = Lead.query.filter(
                Lead.id.in_(lead_ids),
                Lead.tenant_id == tenant_id
            ).all()
        else:
            # System admin without impersonation - can delete any lead
            leads = Lead.query.filter(Lead.id.in_(lead_ids)).all()
        
        log.info(f"🗑️ Found {len(leads)} leads out of {len(lead_ids)} requested")
        
        # BUILD 157: Allow deletion of found leads - don't fail if some not found
        if len(leads) == 0:
            return jsonify({"error": "No leads found or access denied", "success": False}), 404
        
        # BUILD 172: Delete related records FIRST to avoid FK constraint violations
        actual_lead_ids = [lead.id for lead in leads]
        
        # Delete LeadActivity records
        LeadActivity.query.filter(LeadActivity.lead_id.in_(actual_lead_ids)).delete(synchronize_session=False)
        
        # Delete LeadReminder records
        LeadReminder.query.filter(LeadReminder.lead_id.in_(actual_lead_ids)).delete(synchronize_session=False)
        
        # Delete LeadNote records (has cascade but be explicit)
        # BUILD 173: Handle missing table on older production DBs
        try:
            LeadNote.query.filter(LeadNote.lead_id.in_(actual_lead_ids)).delete(synchronize_session=False)
        except Exception as note_err:
            err_str = str(note_err).lower()
            if 'undefinedtable' in err_str or 'does not exist' in err_str or 'lead_notes' in err_str:
                log.warning(f"⚠️ LeadNote delete skipped (table does not exist)")
            else:
                log.error(f"❌ LeadNote delete error: {note_err}")
                raise  # Re-raise unexpected errors
        
        # Delete LeadMergeCandidate records
        # BUILD 173: Handle missing table on older production DBs
        try:
            LeadMergeCandidate.query.filter(
                db.or_(
                    LeadMergeCandidate.lead_id.in_(actual_lead_ids),
                    LeadMergeCandidate.duplicate_lead_id.in_(actual_lead_ids)
                )
            ).delete(synchronize_session=False)
        except Exception as merge_err:
            err_str = str(merge_err).lower()
            if 'undefinedtable' in err_str or 'does not exist' in err_str or 'lead_merge_candidates' in err_str:
                log.warning(f"⚠️ LeadMergeCandidate delete skipped (table does not exist)")
            else:
                log.error(f"❌ LeadMergeCandidate delete error: {merge_err}")
                raise  # Re-raise unexpected errors
        
        # Clear lead_id references in WhatsAppConversation (set to NULL)
        # BUILD 174: Handle missing models gracefully - use WhatsAppConversation which has lead_id
        try:
            from server.models_sql import WhatsAppConversation
            WhatsAppConversation.query.filter(WhatsAppConversation.lead_id.in_(actual_lead_ids)).update(
                {"lead_id": None}, synchronize_session=False
            )
        except Exception as wa_err:
            err_str = str(wa_err).lower()
            if 'undefinedtable' in err_str or 'does not exist' in err_str or 'cannot import' in err_str:
                log.warning(f"⚠️ WhatsApp conversation clear skipped (table/model not available)")
            else:
                log.warning(f"⚠️ WhatsApp conversation clear skipped: {wa_err}")
        
        # Clear lead_id references in CallLog (set to NULL)
        # BUILD 174: CallLog has lead_id for outbound calls
        try:
            CallLog.query.filter(CallLog.lead_id.in_(actual_lead_ids)).update(
                {"lead_id": None}, synchronize_session=False
            )
        except Exception as call_err:
            log.warning(f"⚠️ CallLog clear skipped: {call_err}")
        
        # Now delete the leads
        deleted_count = 0
        deleted_names = []
        
        for lead in leads:
            deleted_names.append(lead.full_name or f"Lead #{lead.id}")
            db.session.delete(lead)
            deleted_count += 1
        
        db.session.commit()
        
        # Log summary after commit
        log.info(f"🗑️ Bulk deleted by {user.get('email') if user else 'unknown'}: {deleted_names}")
        log.info(f"✅ Bulk delete completed: {deleted_count}/{len(lead_ids)} leads deleted")
        
        return jsonify({
            "success": True,
            "message": f"Bulk delete completed: {deleted_count} leads deleted",
            "deleted_count": deleted_count,
            "total_requested": len(lead_ids)
        })
        
    except Exception as e:
        db.session.rollback()
        log.error(f"❌ Bulk delete error: {e}")
        import traceback
        log.error(traceback.format_exc())
        return jsonify({"error": f"Failed to delete leads: {str(e)}", "success": False}), 500

@leads_bp.route("/api/leads/bulk", methods=["PATCH"])
@require_api_auth()  # BUILD 137: Added missing decorator
def bulk_update_leads():
    """Bulk update multiple leads"""
    # BUILD 137: Authentication handled by @require_api_auth() decorator
    
    tenant_id = get_current_tenant()
    if not tenant_id:
        return jsonify({"error": "No tenant access"}), 403
    
    data = request.get_json()
    if not data or 'lead_ids' not in data or 'updates' not in data:
        return jsonify({"error": "lead_ids and updates are required"}), 400
    
    lead_ids = data['lead_ids']
    updates = data['updates']
    
    if not isinstance(lead_ids, list) or len(lead_ids) == 0:
        return jsonify({"error": "lead_ids must be a non-empty array"}), 400
    
    # Validate access to all leads
    leads = Lead.query.filter(
        Lead.id.in_(lead_ids),
        Lead.tenant_id == tenant_id
    ).all()
    
    if len(leads) != len(lead_ids):
        return jsonify({"error": "Some leads not found or access denied"}), 404
    
    # Apply updates
    updated_count = 0
    user = get_current_user()
    
    for lead in leads:
        changes = {}
        
        # Update allowed fields
        for field in ['status', 'owner_user_id', 'tags']:
            if field in updates:
                old_value = getattr(lead, field)
                new_value = updates[field]
                if old_value != new_value:
                    changes[field] = {"from": old_value, "to": new_value}
                    setattr(lead, field, new_value)
        
        if changes:
            lead.updated_at = datetime.utcnow()
            updated_count += 1
            
            # Log bulk update
            create_activity(
                lead.id,
                "bulk_update",
                {
                    "changes": changes,
                    "updated_by": user.get('email', 'unknown') if user else 'unknown'
                },
                user.get('id') if user else None
            )
    
    db.session.commit()
    
    return jsonify({
        "message": f"Bulk update completed: {updated_count} leads updated",
        "updated_count": updated_count,
        "total_requested": len(lead_ids)
    })

# Placeholder for WhatsApp integration - will be implemented in task 7
@leads_bp.route("/api/leads/<int:lead_id>/message/whatsapp", methods=["POST"])
@require_api_auth()  # BUILD 137: Added missing decorator
def send_whatsapp_message(lead_id):
    """Send WhatsApp message to lead"""
    # BUILD 137: Authentication handled by @require_api_auth() decorator
    
    if not check_lead_access(lead_id):
        return jsonify({"error": "Lead not found or access denied"}), 404
    
    # TODO: Implement WhatsApp integration in task 7
    return jsonify({"message": "WhatsApp integration coming soon"}), 501

# ====================================
# General Reminders Endpoints (CRM)
# ====================================

@leads_bp.route("/api/reminders", methods=["GET"])
@require_api_auth()  # BUILD 136 FIX: Use proper decorator that sets g.user and g.tenant
def get_all_reminders():
    """Get all reminders for current business/tenant"""
    tenant_id = get_current_tenant()
    if not tenant_id:
        return jsonify({"error": "No tenant access"}), 403
    
    # Get all reminders for this tenant (both lead-specific and general)
    reminders = LeadReminder.query.filter_by(tenant_id=tenant_id).order_by(LeadReminder.due_at.desc()).all()
    
    # Get lead names for display
    lead_names = {}
    lead_ids = [r.lead_id for r in reminders if r.lead_id]
    if lead_ids:
        leads = Lead.query.filter(Lead.id.in_(lead_ids)).all()
        lead_names = {l.id: l.full_name or f"{l.first_name or ''} {l.last_name or ''}".strip() for l in leads}
    
    return jsonify({
        "reminders": [
            {
                "id": r.id,
                "lead_id": r.lead_id,
                "lead_name": lead_names.get(r.lead_id) if r.lead_id else None,
                "due_at": r.due_at.isoformat() if r.due_at else None,
                "note": r.note,
                "description": r.description or r.note,  # BUILD 143: Use actual description
                "channel": r.channel,
                "priority": r.priority or "medium",  # BUILD 143: Use actual priority
                "reminder_type": r.reminder_type or "general",  # BUILD 143: Use actual type
                "completed_at": r.completed_at.isoformat() if r.completed_at else None,
                "created_by": r.created_by,
                "created_at": r.created_at.isoformat() if r.created_at else None
            }
            for r in reminders
        ]
    })

@leads_bp.route("/api/reminders", methods=["POST"])
@require_api_auth()  # BUILD 142 FINAL: Allow all authenticated users (owner/admin/agent)
def create_general_reminder():
    """Create a new reminder (with or without lead association)"""
    log.info(f"📝 CREATE REMINDER - Starting")
    
    tenant_id = get_current_tenant()
    log.info(f"📝 CREATE REMINDER - tenant_id={tenant_id}")
    if not tenant_id:
        log.error(f"❌ CREATE REMINDER - No tenant access")
        return jsonify({"error": "No tenant access"}), 403
    
    data = request.get_json()
    log.info(f"📝 CREATE REMINDER - data={data}")
    if not data or 'due_at' not in data or 'note' not in data:
        log.error(f"❌ CREATE REMINDER - Missing required fields: due_at={data.get('due_at')}, note={data.get('note')}")
        return jsonify({"error": "due_at and note are required"}), 400
    
    try:
        due_at = datetime.fromisoformat(data['due_at'].replace('Z', '+00:00'))
    except ValueError:
        return jsonify({"error": "Invalid due_at format. Use ISO format"}), 400
    
    # If lead_id is provided, verify access
    lead_id = data.get('lead_id')
    if lead_id:
        lead = Lead.query.filter_by(id=lead_id, tenant_id=tenant_id).first()
        if not lead:
            return jsonify({"error": "Lead not found or access denied"}), 404
    
    user = get_current_user()
    
    reminder = LeadReminder()
    reminder.tenant_id = tenant_id  # Direct tenant ownership
    reminder.lead_id = lead_id if lead_id else None  # Optional lead association
    reminder.due_at = due_at
    reminder.note = data.get('note')
    reminder.description = data.get('description')  # BUILD 143: Additional details
    reminder.channel = data.get('channel', 'ui')
    reminder.priority = data.get('priority', 'medium')  # BUILD 143: low|medium|high
    reminder.reminder_type = data.get('reminder_type', 'general')  # BUILD 143: general|lead_related
    reminder.created_by = user.get('id') if user else None
    
    db.session.add(reminder)
    
    # Log reminder creation only if associated with a lead
    if lead_id:
        create_activity(
            lead_id,
            "reminder_created",
            {
                "due_at": due_at.isoformat(),
                "note": data.get('note'),
                "channel": data.get('channel', 'ui'),
                "created_by": user.get('email', 'unknown') if user else 'unknown'
            },
            user.get('id') if user else None
        )
    
    db.session.commit()
    log.info(f"✅ CREATE REMINDER - Success! reminder_id={reminder.id}, tenant_id={tenant_id}")
    
    return jsonify({
        "message": "Reminder created successfully",
        "reminder": {
            "id": reminder.id,
            "lead_id": reminder.lead_id,
            "due_at": reminder.due_at.isoformat(),
            "note": reminder.note
        }
    }), 201

@leads_bp.route("/api/reminders/<int:reminder_id>", methods=["PATCH"])
@require_api_auth()  # BUILD 137: Added missing decorator
def update_general_reminder(reminder_id):
    """Update or complete a general reminder"""
    # BUILD 137: Authentication handled by @require_api_auth() decorator
    
    tenant_id = get_current_tenant()
    if not tenant_id:
        return jsonify({"error": "No tenant access"}), 403
    
    # Find reminder by ID and tenant_id for security
    reminder = LeadReminder.query.filter_by(id=reminder_id, tenant_id=tenant_id).first()
    if not reminder:
        return jsonify({"error": "Reminder not found"}), 404
    
    data = request.get_json()
    if not data:
        return jsonify({"error": "JSON data required"}), 400
    
    # Update allowed fields
    if 'due_at' in data:
        try:
            reminder.due_at = datetime.fromisoformat(data['due_at'].replace('Z', '+00:00'))
        except ValueError:
            return jsonify({"error": "Invalid due_at format. Use ISO format"}), 400
    
    if 'note' in data:
        reminder.note = data['note']
    
    if 'description' in data:
        reminder.note = data['description']  # Use note field for description
    
    if 'completed_at' in data:
        if data['completed_at']:
            reminder.completed_at = datetime.fromisoformat(data['completed_at'].replace('Z', '+00:00'))
        else:
            reminder.completed_at = None
        
        # Log completion only if associated with a lead and being marked complete
        if reminder.lead_id and data['completed_at']:
            user = get_current_user()
            create_activity(
                reminder.lead_id,
                "reminder_completed",
                {
                    "reminder_id": reminder_id,
                    "note": reminder.note,
                    "completed_by": user.get('email', 'unknown') if user else 'unknown'
                },
                user.get('id') if user else None
            )
    
    if 'completed' in data and data['completed']:
        reminder.completed_at = datetime.utcnow()
        
        # Log completion only if associated with a lead
        if reminder.lead_id:
            user = get_current_user()
            create_activity(
                reminder.lead_id,
                "reminder_completed",
                {
                    "reminder_id": reminder_id,
                    "note": reminder.note,
                    "completed_by": user.get('email', 'unknown') if user else 'unknown'
                },
                user.get('id') if user else None
            )
    
    db.session.commit()
    
    return jsonify({"message": "Reminder updated successfully"})

@leads_bp.route("/api/reminders/<int:reminder_id>", methods=["DELETE"])
@require_api_auth()  # BUILD 137: Added missing decorator
def delete_general_reminder(reminder_id):
    """Delete a general reminder"""
    # BUILD 137: Authentication handled by @require_api_auth() decorator
    
    tenant_id = get_current_tenant()
    if not tenant_id:
        return jsonify({"error": "No tenant access"}), 403
    
    # Find reminder by ID and tenant_id for security
    reminder = LeadReminder.query.filter_by(id=reminder_id, tenant_id=tenant_id).first()
    if not reminder:
        return jsonify({"error": "Reminder not found"}), 404
    
    db.session.delete(reminder)
    db.session.commit()
    
    return jsonify({"message": "Reminder deleted successfully"})


# === LEAD NOTES API ===
# BUILD 172: Permanent notes with edit/delete and file attachments

MAX_FILE_SIZE_BYTES = 10 * 1024 * 1024  # 10MB limit

@leads_bp.route("/api/leads/<int:lead_id>/notes", methods=["GET"])
@require_api_auth()
def get_lead_notes(lead_id):
    """Get all notes for a lead - excludes WhatsApp/call logs, only manual notes"""
    tenant_id = get_current_tenant()
    if not tenant_id:
        return jsonify({"error": "No tenant access"}), 403
    
    lead = Lead.query.filter_by(id=lead_id, tenant_id=tenant_id).first()
    if not lead:
        return jsonify({"error": "Lead not found"}), 404
    
    notes = LeadNote.query.filter_by(lead_id=lead_id, tenant_id=tenant_id).order_by(
        LeadNote.created_at.desc()
    ).all()
    
    return jsonify({
        "success": True,
        "notes": [{
            "id": note.id,
            "content": note.content,
            "attachments": note.attachments or [],
            "created_at": note.created_at.isoformat() if note.created_at else None,
            "updated_at": note.updated_at.isoformat() if note.updated_at else None
        } for note in notes]
    })


@leads_bp.route("/api/leads/<int:lead_id>/notes", methods=["POST"])
@require_api_auth()
def create_lead_note(lead_id):
    """Create a new note for a lead"""
    tenant_id = get_current_tenant()
    if not tenant_id:
        return jsonify({"error": "No tenant access"}), 403
    
    lead = Lead.query.filter_by(id=lead_id, tenant_id=tenant_id).first()
    if not lead:
        return jsonify({"error": "Lead not found"}), 404
    
    data = request.get_json()
    if not data or not data.get('content', '').strip():
        return jsonify({"error": "Note content is required"}), 400
    
    user = get_current_user()
    
    note = LeadNote()
    note.lead_id = lead_id
    note.tenant_id = tenant_id
    note.content = data['content'].strip()
    note.attachments = data.get('attachments', [])
    note.created_by = user.get('id') if user else None
    
    db.session.add(note)
    db.session.commit()
    
    return jsonify({
        "success": True,
        "note": {
            "id": note.id,
            "content": note.content,
            "attachments": note.attachments or [],
            "created_at": note.created_at.isoformat() if note.created_at else None,
            "updated_at": note.updated_at.isoformat() if note.updated_at else None
        }
    }), 201


@leads_bp.route("/api/leads/<int:lead_id>/notes/<int:note_id>", methods=["PATCH"])
@require_api_auth()
def update_lead_note(lead_id, note_id):
    """Update an existing note"""
    tenant_id = get_current_tenant()
    if not tenant_id:
        return jsonify({"error": "No tenant access"}), 403
    
    note = LeadNote.query.filter_by(id=note_id, lead_id=lead_id, tenant_id=tenant_id).first()
    if not note:
        return jsonify({"error": "Note not found"}), 404
    
    data = request.get_json()
    if not data:
        return jsonify({"error": "No data provided"}), 400
    
    if 'content' in data:
        note.content = data['content'].strip()
    
    if 'attachments' in data:
        note.attachments = data['attachments']
    
    note.updated_at = datetime.utcnow()
    db.session.commit()
    
    return jsonify({
        "success": True,
        "note": {
            "id": note.id,
            "content": note.content,
            "attachments": note.attachments or [],
            "created_at": note.created_at.isoformat() if note.created_at else None,
            "updated_at": note.updated_at.isoformat() if note.updated_at else None
        }
    })


@leads_bp.route("/api/leads/<int:lead_id>/notes/<int:note_id>", methods=["DELETE"])
@require_api_auth()
def delete_lead_note(lead_id, note_id):
    """Delete a note"""
    tenant_id = get_current_tenant()
    if not tenant_id:
        return jsonify({"error": "No tenant access"}), 403
    
    note = LeadNote.query.filter_by(id=note_id, lead_id=lead_id, tenant_id=tenant_id).first()
    if not note:
        return jsonify({"error": "Note not found"}), 404
    
    db.session.delete(note)
    db.session.commit()
    
    return jsonify({"success": True, "message": "Note deleted successfully"})


@leads_bp.route("/api/leads/<int:lead_id>/notes/<int:note_id>/upload", methods=["POST"])
@require_api_auth()
def upload_note_attachment(lead_id, note_id):
    """Upload file attachment to a note - max 10MB"""
    import base64
    import uuid
    import os
    
    tenant_id = get_current_tenant()
    if not tenant_id:
        return jsonify({"error": "No tenant access"}), 403
    
    note = LeadNote.query.filter_by(id=note_id, lead_id=lead_id, tenant_id=tenant_id).first()
    if not note:
        return jsonify({"error": "Note not found"}), 404
    
    if 'file' not in request.files:
        return jsonify({"error": "No file provided"}), 400
    
    file = request.files['file']
    if file.filename == '':
        return jsonify({"error": "No file selected"}), 400
    
    # Check file size
    file.seek(0, 2)  # Seek to end
    size = file.tell()
    file.seek(0)  # Reset to start
    
    if size > MAX_FILE_SIZE_BYTES:
        return jsonify({"error": f"File too large. Maximum size is 10MB"}), 400
    
    # Generate unique filename
    filename = file.filename or 'file'
    ext = os.path.splitext(filename)[1]
    unique_name = f"{uuid.uuid4()}{ext}"
    
    # Save to uploads directory
    uploads_dir = os.path.join(os.getcwd(), 'uploads', 'notes', str(tenant_id))
    os.makedirs(uploads_dir, exist_ok=True)
    
    file_path = os.path.join(uploads_dir, unique_name)
    file.save(file_path)
    
    # Determine file type
    file_type = 'image' if file.content_type and file.content_type.startswith('image/') else 'file'
    
    # Add to note attachments
    attachment = {
        "id": str(uuid.uuid4()),
        "name": file.filename,
        "url": f"/uploads/notes/{tenant_id}/{unique_name}",
        "type": file_type,
        "size": size
    }
    
    attachments = note.attachments or []
    attachments.append(attachment)
    note.attachments = attachments
    note.updated_at = datetime.utcnow()
    
    db.session.commit()
    
    return jsonify({
        "success": True,
        "attachment": attachment
    })