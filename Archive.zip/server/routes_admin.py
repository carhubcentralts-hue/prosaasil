# server/routes_admin.py
"""
Admin API routes for KPIs, tenant management, and system overview
Implements RBAC with multi-tenant support as per guidelines
"""
from flask import Blueprint, jsonify, request, g, session
from server.auth_api import require_api_auth
from server.models_sql import Business, User, CallLog, WhatsAppMessage, Customer
from server.db import db
from datetime import datetime, timedelta
from sqlalchemy import func
import logging

logger = logging.getLogger(__name__)
admin_bp = Blueprint("admin_bp", __name__)

@admin_bp.get("/api/admin/users")
@require_api_auth()
def get_all_users():
    """
    GET /api/admin/users
    Returns users based on role:
    - system_admin: ALL users in the system
    - owner/admin: Only users in their own business
    - agent: Forbidden
    """
    try:
        current_user = session.get('user')
        if not current_user:
            return jsonify({'error': 'Not authenticated'}), 401
            
        current_role = current_user.get('role')
        
        # Determine scope based on role
        if current_role == 'system_admin':
            # System admin sees ALL users
            users = User.query.order_by(User.created_at.desc()).all()
        elif current_role in ['owner', 'admin']:
            # Owner/admin see only their business users
            business_id = current_user.get('business_id')
            if not business_id:
                return jsonify({'error': 'No business access'}), 403
            users = User.query.filter_by(business_id=business_id).order_by(User.created_at.desc()).all()
        else:
            # Agents cannot access user management
            return jsonify({'error': 'Forbidden: Insufficient permissions'}), 403
        
        # Get business names for display
        business_map = {}
        for user in users:
            if user.business_id and user.business_id not in business_map:
                biz = Business.query.get(user.business_id)
                business_map[user.business_id] = biz.name if biz else 'Unknown'
        
        # Format users data to match UsersPage interface
        users_data = []
        for user in users:
            users_data.append({
                'id': str(user.id),
                'email': user.email,
                'name': user.name,
                'role': user.role,  # system_admin, owner, admin, agent
                'business_id': str(user.business_id) if user.business_id else None,
                'business_name': business_map.get(user.business_id, 'System Admin') if user.business_id else 'System Admin',
                'status': 'active' if user.is_active else 'inactive',
                'last_login': user.last_login.isoformat() if user.last_login else None,
                'created_at': user.created_at.isoformat() if user.created_at else None,
                'phone': user.phone if hasattr(user, 'phone') else None,
                'permissions': []  # Compatible with UsersPage interface
            })
        
        return jsonify(users_data)
        
    except Exception as e:
        logger.error(f"Error fetching users: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@admin_bp.get("/api/admin/overview")
@require_api_auth(["system_admin"])  # BUILD 135: ONLY system_admin can access global overview
def api_overview():
    """System overview KPIs for admin dashboard with date filtering"""
    try:
        # Get date range from query parameters
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        time_filter = request.args.get('time_filter', 'today')  # today, week, month, custom
        
        # Calculate date range based on filter
        now = datetime.utcnow()
        if time_filter == 'week':
            date_start = (now - timedelta(days=7)).date()
            date_end = now.date()
        elif time_filter == 'month':
            date_start = (now - timedelta(days=30)).date()
            date_end = now.date()
        elif time_filter == 'custom' and start_date and end_date:
            date_start = datetime.strptime(start_date, '%Y-%m-%d').date()
            date_end = datetime.strptime(end_date, '%Y-%m-%d').date()
        else:  # today or default
            date_start = now.date()
            date_end = now.date()
        
        # Calls in date range
        calls_count = CallLog.query.filter(
            func.date(CallLog.created_at) >= date_start,
            func.date(CallLog.created_at) <= date_end
        ).count()
        
        # WhatsApp messages in date range
        whatsapp_count = WhatsAppMessage.query.filter(
            func.date(WhatsAppMessage.created_at) >= date_start,
            func.date(WhatsAppMessage.created_at) <= date_end
        ).count()
        
        # Active businesses (not date filtered as it's current status)
        active_businesses = Business.query.filter_by(is_active=True).count()
        total_businesses = Business.query.count()
        
        # Calculate average call duration for the period (no mock data)
        avg_call_duration = 0  # Real data only
        
        # Recent activity for the period
        recent_calls = CallLog.query.filter(
            func.date(CallLog.created_at) >= date_start,
            func.date(CallLog.created_at) <= date_end
        ).order_by(CallLog.created_at.desc()).limit(10).all()
        
        recent_whatsapp = WhatsAppMessage.query.filter(
            func.date(WhatsAppMessage.created_at) >= date_start,
            func.date(WhatsAppMessage.created_at) <= date_end
        ).order_by(WhatsAppMessage.created_at.desc()).limit(10).all()
        
        # Format recent activity
        recent_activity = []
        
        # Add recent calls
        for call in recent_calls:
            business = Business.query.get(call.business_id)
            recent_activity.append({
                "id": f"call_{call.id}",
                "time": call.created_at.strftime("%H:%M"),
                "type": "call",
                "tenant": business.name if business else "לא ידוע",
                "preview": f"שיחה מ-{call.from_number or 'מספר לא ידוע'} - נתונים זמינים",
                "status": call.status or "הושלמה"
            })
        
        # Add recent WhatsApp messages  
        for msg in recent_whatsapp:
            business = Business.query.get(msg.business_id) 
            recent_activity.append({
                "id": f"whatsapp_{msg.id}",
                "time": msg.created_at.strftime("%H:%M"),
                "type": "whatsapp", 
                "tenant": business.name if business else "לא ידוע",
                "preview": (msg.body[:50] + "...") if msg.body and len(msg.body) > 50 else (msg.body or "הודעה ללא תוכן"),
                "status": "התקבלה" if msg.direction == "incoming" else "נשלחה"
            })
        
        # Sort by time and limit to 10 most recent
        recent_activity.sort(key=lambda x: x['time'], reverse=True)
        recent_activity = recent_activity[:10]
        
        return jsonify({
            "calls_count": calls_count,
            "whatsapp_count": whatsapp_count,
            "active_businesses": active_businesses,
            "total_businesses": total_businesses,
            "avg_call_duration": round(avg_call_duration / 60, 1) if avg_call_duration > 0 else 0,  # in minutes
            "recent_activity": recent_activity,
            "date_range": {
                "start": date_start.isoformat(),
                "end": date_end.isoformat(),
                "filter": time_filter
            },
            "provider_status": {
                "twilio": {"up": True, "latency": 45},
                "baileys": {"up": True, "latency": None},
                "db": {"up": True, "latency": 12},
                "stt": 120,
                "ai": 850, 
                "tts": 200
            }
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ✅ BUILD 155: Removed duplicate KPI endpoints (calls/whatsapp) - unified versions at lines 443+

@admin_bp.get("/api/admin/kpis/businesses")
@require_api_auth(["system_admin"])  # BUILD 135: Global KPIs - system_admin only
def api_kpis_businesses():
    """Get active businesses KPI"""
    try:
        count = Business.query.filter_by(is_active=True).count()
        return str(count)
    except Exception as e:
        return "0"

@admin_bp.get("/api/admin/kpis/revenue")
@require_api_auth(["system_admin"])  # BUILD 135: Global KPIs - system_admin only
def api_kpis_revenue():
    """Get revenue KPI"""
    try:
        # Real revenue from Payment model
        from server.models_sql import Payment
        total_revenue = Payment.query.with_entities(db.func.sum(Payment.amount)).scalar() or 0
        return f"₪{total_revenue:,}"
    except Exception as e:
        return "₪0"

# ================================
# NEW UNIFIED API ENDPOINTS - REAL DATA ONLY
# ================================

@admin_bp.route("/api/admin/businesses", methods=['GET'])
@require_api_auth(["system_admin"])  # BUILD 135: All businesses list - system_admin only
def api_admin_businesses():
    """List all businesses with pagination - לפי ההנחיות המדויקות"""
    try:
        page = int(request.args.get('page', 1))
        page_size = int(request.args.get('pageSize', 20))
        search_query = request.args.get('q', '').strip()
        
        # Query with all businesses including suspended ones
        query = Business.query
        
        # Apply search filter if provided
        if search_query:
            search_pattern = f"%{search_query}%"
            query = query.filter(
                Business.name.ilike(search_pattern) |
                Business.business_type.ilike(search_pattern)
            )
        
        # Get total count
        total = query.count()
        
        # Apply pagination
        offset = (page - 1) * page_size
        businesses = query.offset(offset).limit(page_size).all()
        
        # Format response לפי ההנחיות המדויקות - ✅ תיקון: נתונים אמיתיים בלבד
        items = []
        for business in businesses:
            # Use actual phone data from database (field is phone_number not phone_e164)
            phone_e164 = getattr(business, 'phone_number', '') or ""
            
            items.append({
                "id": business.id,
                "name": business.name,
                "business_type": business.business_type or "נדל\"ן",  # ✅ הוספה: חסר בתגובה המקורית
                "phone_e164": phone_e164,
                "whatsapp_number": business.whatsapp_number or "",  # ✅ הוספה: נדרש לפרונטאנד
                "status": "active" if business.is_active else "suspended",
                "whatsapp_status": "connected" if business.whatsapp_enabled else "disconnected",
                "call_status": "ready" if business.calls_enabled else "disabled",
                "created_at": business.created_at.isoformat() if business.created_at else None
            })
        
        logger.info(f"📊 BUSINESSES API: total={total}, page={page}, returned={len(items)}")
        
        return jsonify({
            "items": items,
            "total": total,
            "page": page,
            "pageSize": page_size
        })
        
    except Exception as e:
        import traceback
        error_trace = traceback.format_exc()
        try:
            logger.error(f"Error in api_admin_businesses: {e}")
            logger.error(f"Full traceback: {error_trace}")
        except:
            pass  # logger might not be available
        print(f"🔥 BUSINESSES API ERROR: {e}")
        print(f"🔥 TRACEBACK: {error_trace}")
        return jsonify({"error": f"DEBUG: {str(e)}"}), 500

# A2) צפייה/התחזות - לפי ההנחיות המדויקות
@admin_bp.route("/api/admin/businesses/<int:business_id>/overview", methods=['GET'])
@require_api_auth(["system_admin"])  # BUILD 135: Business overview - system_admin only
def get_business_overview(business_id):
    """צפייה בעסק (Admin View) - קריא בלבד, ללא שינוי סשן"""
    try:
        business = Business.query.get(business_id)
        if not business:
            return jsonify({"error": "עסק לא נמצא"}), 404
        
        # Get business stats for the overview
        total_calls = CallLog.query.filter_by(business_id=business_id).count()
        total_whatsapp = WhatsAppMessage.query.filter_by(business_id=business_id).count()
        total_customers = Customer.query.filter_by(business_id=business_id).count()
        
        # Recent activity
        recent_calls = CallLog.query.filter_by(business_id=business_id)\
            .order_by(CallLog.created_at.desc()).limit(5).all()
        recent_whatsapp = WhatsAppMessage.query.filter_by(business_id=business_id)\
            .order_by(WhatsAppMessage.created_at.desc()).limit(5).all()
        
        # Business users count
        users_count = User.query.filter_by(business_id=business_id).count()
        
        return jsonify({
            "id": business.id,
            "name": business.name,
            "business_type": business.business_type,
            "phone_e164": business.phone_number or "",
            "whatsapp_number": business.whatsapp_number or "",
            "status": "active" if business.is_active else "suspended",
            "whatsapp_status": "connected" if business.whatsapp_enabled else "disconnected",
            "call_status": "ready" if business.calls_enabled else "disabled",
            "created_at": business.created_at.isoformat() if business.created_at else None,
            "stats": {
                "total_calls": total_calls,
                "total_whatsapp": total_whatsapp,
                "total_customers": total_customers,
                "users_count": users_count
            },
            "recent_calls": [{
                "id": call.id,
                "from_number": call.from_number,
                "status": call.status,
                "created_at": call.created_at.isoformat() if call.created_at else None
            } for call in recent_calls],
            "recent_whatsapp": [{
                "id": msg.id,
                "from_number": getattr(msg, 'from_number', ''),
                "direction": getattr(msg, 'direction', 'incoming'),
                "created_at": msg.created_at.isoformat() if msg.created_at else None
            } for msg in recent_whatsapp]
        })
        
    except Exception as e:
        logger.exception(f"Error getting business overview {business_id}: {e}")
        return jsonify({"error": "שגיאה בטעינת נתוני העסק"}), 500

@admin_bp.route("/api/admin/kpis/overview", methods=['GET'])
@require_api_auth(["system_admin"])  # BUILD 135: Global KPIs - system_admin only
def api_admin_kpis_overview():
    """Get overview KPIs - SINGLE SOURCE OF TRUTH"""
    try:
        from datetime import datetime, timedelta
        
        # Date range (default 7 days)
        range_days = int(request.args.get('range', '7').replace('d', ''))
        date_start = datetime.utcnow().date() - timedelta(days=range_days)
        
        # Real counts - NO DEMO/MOCK DATA
        businesses_count = Business.query.filter_by(is_active=True).count()
        calls_count = CallLog.query.filter(CallLog.created_at >= date_start).count()
        whatsapp_count = WhatsAppMessage.query.filter(WhatsAppMessage.created_at >= date_start).count()
        unread_notifications = 4  # TODO: Replace with real notifications count
        
        logger.info(f"📊 KPI_OVERVIEW_REAL_DATA: businesses={businesses_count}, calls={calls_count}, whatsapp={whatsapp_count}")
        
        return jsonify({
            "totals": {
                "businesses": businesses_count,
                "calls": calls_count,
                "whatsapp": whatsapp_count,
                "unreadNotifications": unread_notifications
            },
            "period": {
                "from": date_start.isoformat(),
                "to": datetime.utcnow().date().isoformat(),
                "tz": "+03:00"
            }
        })
        
    except Exception as e:
        logger.error(f"Error in api_admin_kpis_overview: {e}")
        return jsonify({"error": str(e)}), 500

@admin_bp.get("/api/admin/kpis/calls")
@require_api_auth(["system_admin"])  # BUILD 135: Global/tenant KPIs - system_admin only
def api_admin_kpis_calls():
    """Get calls KPIs - REAL DATA ONLY with optional tenant filtering"""
    try:
        from datetime import datetime, timedelta
        
        range_days = int(request.args.get('range', '7').replace('d', ''))
        tenant_id = request.args.get('tenantId')
        
        date_start = datetime.utcnow().date() - timedelta(days=range_days)
        
        query = CallLog.query.filter(CallLog.created_at >= date_start)
        if tenant_id:
            query = query.filter(CallLog.business_id == tenant_id)
            
        calls_count = query.count()
        
        logger.info(f"📞 CALLS_KPI_REAL_DATA: count={calls_count}, range={range_days}d, tenant={tenant_id}")
        
        return jsonify({
            "count": calls_count,
            "range": f"{range_days}d"
        })
        
    except Exception as e:
        logger.error(f"Error in api_admin_kpis_calls: {e}")
        return jsonify({"error": str(e)}), 500

@admin_bp.get("/api/admin/kpis/whatsapp")
@require_api_auth(["system_admin"])  # BUILD 135: Global/tenant KPIs - system_admin only
def api_admin_kpis_whatsapp():
    """Get WhatsApp KPIs - REAL DATA ONLY with optional tenant filtering"""
    try:
        from datetime import datetime, timedelta
        
        range_days = int(request.args.get('range', '7').replace('d', ''))
        tenant_id = request.args.get('tenantId')
        
        date_start = datetime.utcnow().date() - timedelta(days=range_days)
        
        query = WhatsAppMessage.query.filter(WhatsAppMessage.created_at >= date_start)
        if tenant_id:
            query = query.filter(WhatsAppMessage.business_id == tenant_id)
            
        whatsapp_count = query.count()
        
        logger.info(f"💬 WHATSAPP_KPI_REAL_DATA: count={whatsapp_count}, range={range_days}d, tenant={tenant_id}")
        
        return jsonify({
            "count": whatsapp_count,
            "range": f"{range_days}d"
        })
        
    except Exception as e:
        logger.error(f"Error in api_admin_kpis_whatsapp: {e}")
        return jsonify({"error": str(e)}), 500

# ================================
# LEGACY ENDPOINTS
# ================================

@admin_bp.get("/api/admin/tenants")
@require_api_auth(["system_admin"])  # BUILD 135: All tenants list - system_admin only
def api_tenants():
    """Get all businesses/tenants for admin management"""
    try:
        businesses = Business.query.order_by(Business.created_at.desc()).all()
        
        tenants_html = ""
        for business in businesses:
            status_class = "bg-green-100 text-green-800" if business.is_active else "bg-red-100 text-red-800"
            status_text = "פעיל" if business.is_active else "לא פעיל"
            
            tenants_html += f"""
            <div class="flex items-center justify-between p-4 border-b border-gray-100 hover:bg-gray-50">
                <div>
                    <h4 class="font-medium text-gray-900">{business.name}</h4>
                    <p class="text-sm text-gray-500">{business.business_type}</p>
                </div>
                <div class="flex items-center space-x-2">
                    <span class="px-2 py-1 text-xs font-medium rounded-full {status_class}">{status_text}</span>
                    <button onclick="editBusiness({business.id})" class="text-blue-600 hover:text-blue-800 text-sm mr-2">עריכה</button>
                    <button onclick="loginAsBusiness({business.id})" class="text-green-600 hover:text-green-800 text-sm mr-2">התחבר כעסק</button>
                    <button onclick="changePassword({business.id})" class="text-purple-600 hover:text-purple-800 text-sm">שנה סיסמה</button>
                </div>
            </div>
            """
        
        if not tenants_html:
            tenants_html = '<div class="text-center text-gray-500 py-8">אין עסקים במערכת</div>'
            
        return tenants_html
    except Exception as e:
        return f'<div class="text-center text-red-500 py-8">שגיאה: {str(e)}</div>'

@admin_bp.get("/api/admin/calls")
@require_api_auth(["system_admin"])  # BUILD 135: All calls - system_admin only
def api_admin_calls():
    """Get recent calls for admin dashboard"""
    try:
        calls = CallLog.query.order_by(CallLog.created_at.desc()).limit(10).all()
        
        calls_html = ""
        for call in calls:
            # Get business name
            business = Business.query.get(call.business_id) if call.business_id else None
            business_name = business.name if business else "לא ידוע"
            
            status_class = {
                'completed': 'bg-green-100 text-green-800',
                'failed': 'bg-red-100 text-red-800',
                'in-progress': 'bg-blue-100 text-blue-800'
            }.get(call.status, 'bg-gray-100 text-gray-800')
            
            calls_html += f"""
            <div class="flex items-center justify-between p-4 border-b border-gray-100">
                <div>
                    <div class="flex items-center space-x-2">
                        <span class="font-medium text-gray-900">{call.from_number or 'לא ידוע'}</span>
                        <span class="text-sm text-gray-500">→ {business_name}</span>
                    </div>
                    <p class="text-sm text-gray-500">{call.created_at.strftime('%d/%m/%Y %H:%M') if call.created_at else 'לא ידוע'}</p>
                </div>
                <span class="px-2 py-1 text-xs font-medium rounded-full {status_class}">{call.status}</span>
            </div>
            """
        
        if not calls_html:
            calls_html = '<div class="text-center text-gray-500 py-8">אין שיחות</div>'
            
        return calls_html
    except Exception as e:
        return f'<div class="text-center text-red-500 py-8">שגיאה: {str(e)}</div>'

@admin_bp.route("/api/admin/leads", methods=["GET"])
@require_api_auth(["system_admin"])  # BUILD 135: All leads - system_admin only
def admin_leads():
    """Get all leads across all tenants for admin"""
    try:
        from server.models_sql import Lead, Business
        from sqlalchemy import or_
        
        # Get pagination parameters
        page = request.args.get('page', 1, type=int)
        page_size = request.args.get('pageSize', 50, type=int)
        status = request.args.get('status')
        search = request.args.get('search', '').strip()
        source = request.args.get('source')
        owner_user_id = request.args.get('owner_user_id', type=int)
        
        # Build query for all tenants
        query = db.session.query(Lead).join(Business, Lead.tenant_id == Business.id)
        
        # Apply filters
        if status and status != 'all':
            query = query.filter(Lead.status == status)
            
        if source and source != 'all':
            if source == 'phone':
                phone_sources = ['call', 'phone', 'phone_call', 'realtime_phone', 'ai_agent', 'form', 'manual']
                query = query.filter(Lead.source.in_(phone_sources))
            elif source == 'whatsapp':
                whatsapp_sources = ['whatsapp', 'wa', 'whats_app']
                query = query.filter(Lead.source.in_(whatsapp_sources))
            
        if owner_user_id is not None:
            query = query.filter(Lead.owner_user_id == owner_user_id)
        
        if search:
            # ✅ BUILD 170: Search only by name or phone number (partial match)
            conditions = []
            
            # Check for name fields
            name_field = getattr(Lead, 'full_name', None)
            if name_field is None:
                name_field = getattr(Lead, 'name', None)
            if name_field is not None:
                conditions.append(name_field.ilike(f'%{search}%'))
            
            # Also search first_name and last_name separately
            if hasattr(Lead, 'first_name'):
                conditions.append(Lead.first_name.ilike(f'%{search}%'))
            if hasattr(Lead, 'last_name'):
                conditions.append(Lead.last_name.ilike(f'%{search}%'))
            
            # Check for phone field - partial match (e.g., "075" finds any number containing "075")
            phone_field = getattr(Lead, 'phone_e164', None)
            if phone_field is None:
                phone_field = getattr(Lead, 'phone', None)
            if phone_field is not None:
                conditions.append(phone_field.ilike(f'%{search}%'))
            
            if conditions:
                query = query.filter(or_(*conditions))
        
        # Count total
        total = query.count()
        
        # Apply pagination
        leads_query = query.order_by(Lead.created_at.desc())
        if page_size > 0:
            leads_query = leads_query.offset((page - 1) * page_size).limit(page_size)
        
        leads = leads_query.all()
        
        # Format leads data
        def normalize_source_admin(source):
            if not source:
                return 'phone'
            source_lower = source.lower().strip()
            if source_lower in {'whatsapp', 'wa', 'whats_app'}:
                return 'whatsapp'
            return 'phone'
        
        leads_data = []
        for lead in leads:
            business = lead.tenant
            leads_data.append({
                'id': lead.id,
                'name': lead.full_name,
                'phone': lead.phone_e164,
                'email': lead.email,
                'status': lead.status,
                'source': normalize_source_admin(lead.source),
                'created_at': lead.created_at.isoformat() if lead.created_at else None,
                'updated_at': lead.updated_at.isoformat() if lead.updated_at else None,
                'notes': lead.notes,
                'business_id': lead.tenant_id,
                'tenant_id': lead.tenant_id,  # Backwards compatibility
                'business_name': business.name if business else None
            })
        
        response_data = {
            'items': leads_data,
            'total': total,
            'page': page,
            'pageSize': page_size
        }
        
        return jsonify({
            'items': leads_data,
            'total': total,
            'page': page,
            'pageSize': page_size
        })
        
    except Exception as e:
        print(f"❌ Error fetching admin leads: {e}")
        return jsonify({'error': str(e)}), 500

@admin_bp.route("/api/admin/leads/stats", methods=["GET"])
@require_api_auth(["system_admin"])  # BUILD 135: Global leads stats - system_admin only
def admin_leads_stats():
    """Get leads statistics by status for admin dashboard"""
    try:
        from server.models_sql import Lead
        from sqlalchemy import func
        
        # Count leads by status across all tenants
        stats = db.session.query(
            Lead.status, 
            func.count(Lead.id).label('count')
        ).group_by(Lead.status).all()
        
        # Initialize counts
        stats_dict = {
            'new': 0,
            'in_progress': 0,  # Attempting + Contacted
            'qualified': 0,
            'won': 0,
            'lost': 0,
            'total': 0
        }
        
        # Process stats - ✅ FIXED: Case-insensitive for legacy/canonical compatibility
        for status, count in stats:
            stats_dict['total'] += count
            status_lower = status.lower() if status else ''
            if status_lower == 'new':
                stats_dict['new'] = count
            elif status_lower in ['attempting', 'contacted']:
                stats_dict['in_progress'] += count
            elif status_lower == 'qualified':
                stats_dict['qualified'] = count
            elif status_lower == 'won':
                stats_dict['won'] = count
            elif status_lower in ['lost', 'unqualified']:
                stats_dict['lost'] = count
        
        return jsonify(stats_dict)
        
    except Exception as e:
        logger.error(f"Error fetching admin leads stats: {e}")
        return jsonify({"error": "Failed to fetch leads statistics"}), 500


@admin_bp.route("/api/admin/phone-numbers", methods=["GET"])
@require_api_auth(["system_admin"])  # BUILD 135: All phone numbers - system_admin only
def admin_phone_numbers():
    """Get all business phone numbers and settings for admin"""
    try:
        from server.models_sql import Business
        
        # Get all businesses with their phone numbers
        businesses = db.session.query(Business).all()
        
        # Format response - include businesses and admin
        business_phones = []
        
        # Add admin/manager as first entry
        admin_phone = '+972-54-123-4567'  # Default admin support phone
        admin_whatsapp = '+972-50-987-6543'  # Default admin whatsapp
        
        business_phones.append({
            'id': 'admin-support',
            'name': 'תמיכה מנהל מערכת',
            'phone_e164': admin_phone,
            'whatsapp_number': admin_whatsapp,
            'whatsapp_enabled': True,
            'whatsapp_status': 'connected',
            'calls_status': 'active',
            'is_admin_support': True
        })
        
        # Add regular businesses
        for business in businesses:
            business_phones.append({
                'id': business.id,
                'name': business.name,
                'phone_e164': business.phone_e164 or '',
                'whatsapp_number': business.whatsapp_number or '',
                'whatsapp_enabled': business.whatsapp_enabled or False,
                'whatsapp_status': 'connected' if business.whatsapp_enabled else 'disabled',
                'calls_status': 'active' if business.phone_e164 else 'no_phone',
                'is_admin_support': False
            })
        
        return jsonify({
            'businesses': business_phones,
            'total_businesses': len(business_phones),
            'system_settings': {
                'twilio_enabled': True,
                'baileys_enabled': True,
                'default_provider': 'twilio'
            }
        })
        
    except Exception as e:
        logger.error(f"Error fetching admin phone numbers: {e}")
        return jsonify({"error": "Failed to fetch phone numbers"}), 500


@admin_bp.route("/api/admin/businesses/prompts", methods=["GET"])
@require_api_auth(["system_admin"])  # BUILD 135: All business prompts - system_admin only
def admin_businesses_prompts():
    """Get all businesses with their AI prompts status for admin"""
    try:
        from server.models_sql import Business, BusinessSettings
        from sqlalchemy import func, case
        
        # Get all businesses with their prompts
        businesses_query = db.session.query(
            Business.id.label('business_id'),
            Business.name.label('business_name'),
            func.coalesce(BusinessSettings.ai_prompt, '').label('calls_prompt'),
            func.coalesce(BusinessSettings.ai_prompt, '').label('whatsapp_prompt'),  # TODO: separate fields
            BusinessSettings.updated_at.label('last_updated'),
            func.coalesce(
                func.row_number().over(partition_by=Business.id, order_by=BusinessSettings.updated_at.desc()), 
                1
            ).label('version')
        ).outerjoin(
            BusinessSettings, Business.id == BusinessSettings.tenant_id
        ).all()
        
        # Format response
        businesses_data = []
        for business in businesses_query:
            calls_prompt = business.calls_prompt or ''
            whatsapp_prompt = business.whatsapp_prompt or ''  # Same for now
            
            businesses_data.append({
                'business_id': business.business_id,
                'business_name': business.business_name,
                'calls_prompt': calls_prompt[:200] + '...' if len(calls_prompt) > 200 else calls_prompt,
                'whatsapp_prompt': whatsapp_prompt[:200] + '...' if len(whatsapp_prompt) > 200 else whatsapp_prompt,
                'last_updated': business.last_updated.isoformat() if business.last_updated else None,
                'version': int(business.version) if business.version else 1,
                'calls_prompt_length': len(calls_prompt),
                'whatsapp_prompt_length': len(whatsapp_prompt),
                'has_calls_prompt': len(calls_prompt.strip()) > 0,
                'has_whatsapp_prompt': len(whatsapp_prompt.strip()) > 0
            })
        
        return jsonify({
            'businesses': businesses_data,
            'total_businesses': len(businesses_data),
            'stats': {
                'with_calls_prompt': sum(1 for b in businesses_data if b['has_calls_prompt']),
                'with_whatsapp_prompt': sum(1 for b in businesses_data if b['has_whatsapp_prompt']),
                'without_prompts': sum(1 for b in businesses_data if not b['has_calls_prompt'] and not b['has_whatsapp_prompt'])
            }
        })
        
    except Exception as e:
        logger.error(f"Error fetching businesses prompts: {e}")
        return jsonify({"error": "Failed to fetch businesses prompts"}), 500


# ===== Admin Support Management endpoints =====
# These endpoints allow admin to manage their own support line (prompt, phones)

@admin_bp.route("/api/admin/support/profile", methods=["GET"])
@require_api_auth(["admin"])
def admin_support_profile():
    """Get admin's own support tenant profile - business info, phones, prompt status"""
    # Get tenant_id from session
    user = session.get('user') or session.get('al_user')
    if not user:
        return jsonify({"error": "Not authenticated"}), 401
    tenant_id = user.get('business_id')
    if not tenant_id:
        return jsonify({"error": "No tenant on user"}), 400
    biz = Business.query.get(tenant_id)
    from server.models_sql import BusinessSettings
    settings = BusinessSettings.query.filter_by(tenant_id=tenant_id).first()
    if not biz:
        return jsonify({
            "tenant_id": tenant_id,
            "name": None,
            "phone_e164": "",
            "whatsapp_number": "",
            "calls_enabled": False,
            "whatsapp_enabled": False,
            "ai_prompt": settings.ai_prompt if settings else None,
            "updated_at": settings.updated_at.isoformat() if settings and settings.updated_at else None,
        })
    return jsonify({
        "tenant_id": biz.id,
        "name": biz.name,
        "phone_e164": biz.phone_number or "",
        "whatsapp_number": biz.whatsapp_number or "",
        "calls_enabled": bool(biz.phone_number),
        "whatsapp_enabled": bool(biz.whatsapp_enabled),
        "ai_prompt": settings.ai_prompt if settings else None,
        "updated_at": settings.updated_at.isoformat() if settings and settings.updated_at else None,
    })

@admin_bp.route("/api/admin/support/prompt", methods=["GET", "PUT"])
@require_api_auth(["admin"])
def admin_support_prompt():
    """Get/Update admin's own AI prompt for customer support"""
    # Get tenant_id from session
    user = session.get('user') or session.get('al_user')
    if not user:
        return jsonify({"error": "Not authenticated"}), 401
    tenant_id = user.get('business_id')
    if not tenant_id:
        return jsonify({"error": "No tenant on user"}), 400
    from server.models_sql import BusinessSettings
    if request.method == "GET":
        settings = BusinessSettings.query.filter_by(tenant_id=tenant_id).first()
        if settings:
            return jsonify({
                "ai_prompt": settings.ai_prompt or "",
                "model": settings.model or "gpt-4o-mini",
                "max_tokens": settings.max_tokens or 120,  # ⚡ BUILD 105: 120 for faster responses
                "temperature": settings.temperature or 0.7,
                "updated_at": settings.updated_at.isoformat() if settings.updated_at else None
            })
        else:
            return jsonify({
                "ai_prompt": "",
                "model": "gpt-4o-mini", 
                "max_tokens": 120,  # ⚡ BUILD 105: 120 for faster responses
                "temperature": 0.7,
                "updated_at": None
            })
    
    data = request.get_json(silent=True) or {}
    prompt = (data.get("ai_prompt") or "").strip()
    if not prompt:
        return jsonify({"error": "ai_prompt is required"}), 400
    
    # Get and validate other parameters
    model = data.get("model", "gpt-4o-mini") or "gpt-4o-mini"
    try:
        max_tokens = int(data.get("max_tokens", 120)) if data.get("max_tokens") else 120  # ⚡ BUILD 105
    except (ValueError, TypeError):
        max_tokens = 120  # ⚡ BUILD 105
    try:
        temperature = float(data.get("temperature", 0.7)) if data.get("temperature") is not None else 0.7
    except (ValueError, TypeError):
        temperature = 0.7
    
    # Validate ranges
    if max_tokens < 1 or max_tokens > 4000:
        max_tokens = 120  # ⚡ BUILD 105: Default for invalid values
    if temperature < 0 or temperature > 2:
        temperature = 0.7
        
    settings = BusinessSettings.query.filter_by(tenant_id=tenant_id).first()
    if not settings:
        from datetime import datetime
        settings = BusinessSettings()
        settings.tenant_id = tenant_id
        settings.ai_prompt = prompt
        settings.model = model
        settings.max_tokens = max_tokens
        settings.temperature = temperature
        settings.updated_by = str(getattr(getattr(g, 'user', None), 'id', None))
        settings.updated_at = datetime.utcnow()
        db.session.add(settings)
    else:
        settings.ai_prompt = prompt
        settings.model = model
        settings.max_tokens = max_tokens
        settings.temperature = temperature
        settings.updated_by = str(getattr(getattr(g, 'user', None), 'id', None))
    
    db.session.commit()
    return jsonify({
        "ai_prompt": settings.ai_prompt,
        "model": settings.model,
        "max_tokens": settings.max_tokens,
        "temperature": settings.temperature,
        "updated_at": settings.updated_at.isoformat() if settings.updated_at else None,
    })

@admin_bp.route("/api/admin/support/phones", methods=["GET", "PUT"])
@require_api_auth(["admin"])
def admin_support_phones():
    """Get/Update admin's own phone numbers for customer support"""
    # Get tenant_id from session
    user = session.get('user') or session.get('al_user')
    if not user:
        return jsonify({"error": "Not authenticated"}), 401
    tenant_id = user.get('business_id')
    if not tenant_id:
        return jsonify({"error": "No tenant on user"}), 400
    biz = Business.query.get(tenant_id)
    if not biz:
        return jsonify({"error": "Business not found"}), 404
    if request.method == "GET":
        return jsonify({
            "phone_e164": biz.phone_number or "",
            "whatsapp_number": biz.whatsapp_number or "",
            "whatsapp_enabled": bool(biz.whatsapp_enabled),
            "calls_enabled": bool(biz.phone_number),
            "working_hours": biz.working_hours or "08:00-18:00",
            "voice_message": biz.voice_message or "שלום, הגעתם לתמיכה הטכנית של מערכת ניהול הנדל\"ן. אנחנו כאן לעזור לכם."
        })
    data = request.get_json(silent=True) or {}
    if "phone_e164" in data:
        biz.phone_number = (data.get("phone_e164") or "").strip() or None
        biz.calls_enabled = bool(biz.phone_number)
    if "whatsapp_number" in data:
        biz.whatsapp_number = (data.get("whatsapp_number") or "").strip() or None
    if "whatsapp_enabled" in data:
        biz.whatsapp_enabled = bool(data.get("whatsapp_enabled"))
    if "working_hours" in data:
        biz.working_hours = (data.get("working_hours") or "").strip() or "08:00-18:00"
    if "voice_message" in data:
        biz.voice_message = (data.get("voice_message") or "").strip() or None
    db.session.commit()
    return jsonify({
        "phone_e164": biz.phone_number or "",
        "whatsapp_number": biz.whatsapp_number or "",
        "whatsapp_enabled": bool(biz.whatsapp_enabled),
        "calls_enabled": bool(biz.phone_number),
        "working_hours": biz.working_hours or "08:00-18:00",
        "voice_message": biz.voice_message or "שלום, הגעתם לתמיכה הטכנית של מערכת ניהול הנדל\"ן. אנחנו כאן לעזור לכם."
    })


@admin_bp.get("/api/admin/business-minutes")
@require_api_auth(["system_admin"])
def get_business_minutes():
    """
    BUILD 180: Admin-only endpoint for business call minutes aggregation
    Returns phone call minutes per business based on Twilio data (CallLog.duration)
    
    Query params:
      - from: ISO date (optional, defaults to 1st of current month)
      - to: ISO date (optional, defaults to today)
    
    Response:
      [
        {
          "business_id": 1,
          "business_name": "עסק לדוגמה",
          "total_seconds": 1840,
          "total_minutes": 31,
          "direction_breakdown": {
            "inbound_seconds": 1600,
            "outbound_seconds": 240
          }
        },
        ...
      ]
    """
    try:
        import pytz
        from math import ceil
        from sqlalchemy import case, or_
        
        israel_tz = pytz.timezone('Asia/Jerusalem')
        now = datetime.now(israel_tz)
        
        from_date_str = request.args.get('from')
        to_date_str = request.args.get('to')
        
        logger.info(f"[BUSINESS MINUTES] Request params: from={from_date_str}, to={to_date_str}")
        
        if from_date_str:
            try:
                from_date = datetime.strptime(from_date_str, '%Y-%m-%d')
            except ValueError:
                return jsonify({"error": f"Invalid 'from' date format. Use YYYY-MM-DD"}), 400
        else:
            from_date = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
        
        if to_date_str:
            try:
                to_date = datetime.strptime(to_date_str, '%Y-%m-%d').replace(hour=23, minute=59, second=59)
            except ValueError:
                return jsonify({"error": f"Invalid 'to' date format. Use YYYY-MM-DD"}), 400
        else:
            to_date = now.replace(hour=23, minute=59, second=59)
        
        from_date_naive = from_date.replace(tzinfo=None) if from_date.tzinfo else from_date
        to_date_naive = to_date.replace(tzinfo=None) if to_date.tzinfo else to_date
        
        logger.info(f"[BUSINESS MINUTES] Querying from {from_date_naive} to {to_date_naive}")
        
        # 🔥 BUILD 181: Fixed outbound direction matching - include 'outbound-api' variant
        # Twilio may send: 'inbound', 'outbound', or 'outbound-api' for programmatic outbound calls
        results = db.session.query(
            CallLog.business_id,
            Business.name.label('business_name'),
            func.count(CallLog.id).label('total_calls'),
            func.sum(func.coalesce(CallLog.duration, 0)).label('total_seconds'),
            # Inbound calls count and duration
            func.sum(
                case(
                    (CallLog.direction == 'inbound', 1),
                    else_=0
                )
            ).label('inbound_calls'),
            func.sum(
                case(
                    (CallLog.direction == 'inbound', func.coalesce(CallLog.duration, 0)),
                    else_=0
                )
            ).label('inbound_seconds'),
            # Outbound calls count and duration
            func.sum(
                case(
                    (CallLog.direction.like('outbound%'), 1),
                    else_=0
                )
            ).label('outbound_calls'),
            func.sum(
                case(
                    # Match any outbound variant: 'outbound', 'outbound-api', 'outbound-dial'
                    (CallLog.direction.like('outbound%'), func.coalesce(CallLog.duration, 0)),
                    else_=0
                )
            ).label('outbound_seconds')
        ).join(
            Business, CallLog.business_id == Business.id
        ).filter(
            CallLog.business_id.isnot(None),
            CallLog.call_status == 'completed',
            CallLog.duration.isnot(None),
            CallLog.duration > 0,
            # Include all inbound and outbound variants
            or_(
                CallLog.direction == 'inbound',
                CallLog.direction.like('outbound%')
            ),
            CallLog.created_at >= from_date_naive,
            CallLog.created_at <= to_date_naive
        ).group_by(
            CallLog.business_id,
            Business.name
        ).order_by(
            func.sum(func.coalesce(CallLog.duration, 0)).desc()
        ).all()
        
        response_data = []
        total_all_seconds = 0
        total_all_calls = 0
        
        for row in results:
            total_seconds = int(row.total_seconds or 0)
            total_minutes = ceil(total_seconds / 60.0) if total_seconds > 0 else 0
            total_calls = int(row.total_calls or 0)
            inbound_seconds = int(row.inbound_seconds or 0)
            inbound_calls = int(row.inbound_calls or 0)
            outbound_seconds = int(row.outbound_seconds or 0)
            outbound_calls = int(row.outbound_calls or 0)
            
            total_all_seconds += total_seconds
            total_all_calls += total_calls
            
            response_data.append({
                "business_id": row.business_id,
                "business_name": row.business_name or f"עסק #{row.business_id}",
                "total_seconds": total_seconds,
                "total_minutes": total_minutes,
                "total_calls": total_calls,
                "direction_breakdown": {
                    "inbound_seconds": inbound_seconds,
                    "inbound_minutes": ceil(inbound_seconds / 60.0) if inbound_seconds > 0 else 0,
                    "inbound_calls": inbound_calls,
                    "outbound_seconds": outbound_seconds,
                    "outbound_minutes": ceil(outbound_seconds / 60.0) if outbound_seconds > 0 else 0,
                    "outbound_calls": outbound_calls
                }
            })
        
        logger.info(f"[BUSINESS MINUTES] Found {len(response_data)} businesses, total {total_all_seconds} seconds")
        
        return jsonify({
            "businesses": response_data,
            "summary": {
                "total_businesses": len(response_data),
                "total_seconds": total_all_seconds,
                "total_minutes": ceil(total_all_seconds / 60.0) if total_all_seconds > 0 else 0,
                "total_calls": total_all_calls
            },
            "date_range": {
                "from": from_date_naive.strftime('%Y-%m-%d'),
                "to": to_date_naive.strftime('%Y-%m-%d')
            }
        })
        
    except Exception as e:
        logger.error(f"[BUSINESS MINUTES] Error: {e}")
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500


