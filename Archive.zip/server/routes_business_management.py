from flask import Blueprint, request, jsonify, session, g
from werkzeug.security import generate_password_hash
from server.models_sql import Business, User, BusinessSettings, FAQ, db
from datetime import datetime
from server.routes_admin import require_api_auth
from server.extensions import csrf
from functools import wraps
import logging

logger = logging.getLogger(__name__)

# REMOVED custom csrf_exempt decorator - using proper @csrf.exempt from SeaSurf only where needed

def normalize_patterns(payload):
    """
    Normalize patterns_json to ensure it's always a List[str]
    
    Handles:
    - None/null → []
    - String (JSON or plain text) → parse and extract list
    - List → validate and clean
    - Empty strings/whitespace → []
    
    Returns: List[str] or raises ValueError
    """
    import json
    
    if payload is None or payload == "":
        return []
    
    if isinstance(payload, list):
        cleaned = [str(p).strip() for p in payload if p and str(p).strip()]
        return cleaned
    
    if isinstance(payload, str):
        stripped = payload.strip()
        if not stripped:
            return []
        
        try:
            parsed = json.loads(stripped)
            if isinstance(parsed, list):
                cleaned = [str(p).strip() for p in parsed if p and str(p).strip()]
                return cleaned
            else:
                raise ValueError(f"patterns_json must be a list, got {type(parsed).__name__}")
        except json.JSONDecodeError as e:
            raise ValueError(f"patterns_json is not valid JSON: {e}")
    
    raise ValueError(f"patterns_json must be a list or JSON string, got {type(payload).__name__}")

# Business Management Blueprint
biz_mgmt_bp = Blueprint('business_management', __name__)

@biz_mgmt_bp.route('/api/admin/business/<int:business_id>', methods=['GET'])
@require_api_auth(['admin'])
def get_business(business_id):
    """Get business details"""
    try:
        logger.info(f"Looking for business with ID: {business_id}")
        business = Business.query.filter_by(id=business_id).first()
        logger.info(f"Found business: {business}")
        if not business:
            return jsonify({"error": "עסק לא נמצא"}), 404
        
        # JSON לפי ההנחיות המדויקות + ALL fields
        return jsonify({
            "id": business.id,
            "name": business.name,
            "phone_e164": business.phone_e164 or "",
            "whatsapp_number": business.whatsapp_number or "",
            "greeting_message": business.greeting_message or "",
            "whatsapp_greeting": business.whatsapp_greeting or "",
            "system_prompt": business.system_prompt or "",
            "voice_message": business.voice_message or "",
            "working_hours": business.working_hours or "08:00-18:00",
            "phone_permissions": business.phone_permissions,
            "whatsapp_permissions": business.whatsapp_permissions,
            "calls_enabled": business.calls_enabled,
            "crm_enabled": business.crm_enabled,
            "whatsapp_enabled": business.whatsapp_enabled,
            "payments_enabled": business.payments_enabled,
            "default_provider": business.default_provider or "paypal",
            "email": f"office@{business.name.lower().replace(' ', '-')}.co.il",
            "address": "",
            "status": "active" if business.is_active else "inactive",
            "whatsapp_status": "connected",
            "call_status": "ready",
            "created_at": business.created_at.isoformat() if business.created_at else None,
            "updated_at": business.updated_at.isoformat() if business.updated_at else None
        })
    except Exception as e:
        logger.error(f"Error getting business {business_id}: {e}")
        import traceback
        logger.error(f"Full traceback: {traceback.format_exc()}")
        return jsonify({"error": f"שגיאה בטעינת נתוני העסק: {str(e)}"}), 500

@biz_mgmt_bp.route('/api/admin/business', methods=['POST'])
@require_api_auth(['system_admin'])  # BUILD 138: Only system_admin can create businesses
def create_business():
    """Create new business with admin user"""
    try:
        data = request.get_json()
        
        # ✅ לפי ההנחיות: name (חובה), phone_e164 (חובה), timezone (ברירת מחדל)
        required_fields = ['name', 'phone_e164']  # השם שהפרונטאנד שולח
        for field in required_fields:
            if not data.get(field):
                return jsonify({"error": "missing_field", "field": field}), 400
        
        # Check if business name exists
        existing_business = Business.query.filter_by(name=data['name']).first()
        if existing_business:
            return jsonify({"error": "שם העסק כבר קיים"}), 409
        
        # ✅ Validate owner email and password (required for auto-create)
        owner_email = data.get('owner_email')
        owner_password = data.get('owner_password')
        owner_name = data.get('owner_name', data['name'] + ' - Owner')
        
        if not owner_email or not owner_password:
            return jsonify({"error": "owner_email וowner_password נדרשים ליצירת עסק"}), 400
        
        if len(owner_password) < 6:
            return jsonify({"error": "הסיסמה חייבת להכיל לפחות 6 תווים"}), 400
        
        # Check if owner email already exists
        existing_user = User.query.filter_by(email=owner_email).first()
        if existing_user:
            return jsonify({"error": "כתובת האימייל של הבעלים כבר רשומה במערכת"}), 409
        
        # ✅ ATOMIC TRANSACTION: Create business + owner together
        try:
            # Create business - לפי ההנחיות המדויקות + ALL required fields
            business = Business()
            business.name = data['name']
            business.phone_e164 = data['phone_e164']  # השם שהפרונטאנד שולח
            business.business_type = data.get('business_type', 'general')  # 🔥 BUILD 200: Generic default - works for any business type
            business.is_active = True
            
            # Set ALL required fields to prevent NOT NULL constraint violations
            business.whatsapp_number = data.get('whatsapp_number', data['phone_e164'])  # Default to same phone
            business.greeting_message = data.get('greeting_message', "שלום! איך אפשר לעזור?")
            business.whatsapp_greeting = data.get('whatsapp_greeting', "שלום! איך אפשר לעזור?")
            business.system_prompt = data.get('system_prompt', f"אתה נציג שירות מקצועי ב{{{{business_name}}}}. עזור ללקוחות בצורה אדיבה ומקצועית.")  # ✅ כללי - לא מניח סוג עסק!
            business.voice_message = data.get('voice_message', f"שלום מ{{{{business_name}}}}")
            business.working_hours = data.get('working_hours', "08:00-18:00")
            business.phone_permissions = True
            business.whatsapp_permissions = True
            business.calls_enabled = True
            business.crm_enabled = True
            business.whatsapp_enabled = True
            business.payments_enabled = False
            business.default_provider = "paypal"
            
            db.session.add(business)
            db.session.flush()  # Get business.id WITHOUT committing yet
            
            logger.info(f"Creating business {business.name} with owner {owner_email}")
            
            # AUTO-CREATE OWNER USER for new business (same transaction)
            owner_user = User(
                email=owner_email,
                password_hash=generate_password_hash(owner_password, method='scrypt'),
                name=owner_name,
                role='owner',
                business_id=business.id,
                is_active=True,
                created_at=datetime.utcnow()
            )
            db.session.add(owner_user)
            
            # ✅ SINGLE COMMIT: Both business + owner atomically
            db.session.commit()
            logger.info(f"✅ Created business {business.id}: {business.name} with owner {owner_email}")
            
            # 🔥 AUTO-WARMUP: Create agents for new business immediately
            try:
                import threading
                def warmup_new_business(bid, bname):
                    try:
                        from server.agent_tools.agent_factory import create_booking_agent
                        for channel in ['calls', 'whatsapp']:
                            create_booking_agent(bid, channel)
                            logger.info(f"✅ [AUTO-WARMUP] Agent created for business {bid} ({bname}) - {channel}")
                    except Exception as e:
                        logger.warning(f"⚠️ [AUTO-WARMUP] Failed for business {bid}: {e}")
                
                # Run warmup in background to not delay response
                t = threading.Thread(target=warmup_new_business, args=(business.id, business.name), daemon=True)
                t.start()
                logger.info(f"🔥 [AUTO-WARMUP] Started background warmup for business {business.id}")
            except Exception as warmup_error:
                logger.warning(f"⚠️ Auto-warmup failed to start: {warmup_error}")
                
        except Exception as error:
            # Rollback BOTH business and owner if anything fails
            db.session.rollback()
            logger.error(f"Failed to create business or owner, rolling back: {error}")
            import traceback
            logger.error(f"Full traceback: {traceback.format_exc()}")
            return jsonify({"error": "שגיאה ביצירת עסק או משתמש הבעלים"}), 500
        
        # ✅ החזר JSON של העסק החדש עם id + ALL fields (consistent with DB)
        return jsonify({
            "id": business.id,
            "name": business.name,
            "phone_e164": business.phone_e164,
            "whatsapp_number": business.whatsapp_number or "",
            "greeting_message": business.greeting_message or "",
            "whatsapp_greeting": business.whatsapp_greeting or "",
            "system_prompt": business.system_prompt or "",
            "voice_message": business.voice_message or "",
            "working_hours": business.working_hours or "08:00-18:00",
            "phone_permissions": business.phone_permissions,
            "whatsapp_permissions": business.whatsapp_permissions,
            "calls_enabled": business.calls_enabled,
            "crm_enabled": business.crm_enabled,
            "whatsapp_enabled": business.whatsapp_enabled,
            "payments_enabled": business.payments_enabled,
            "default_provider": business.default_provider or "paypal",
            "business_type": business.business_type,
            "is_active": business.is_active,
            "status": "active" if business.is_active else "inactive",
            "call_status": "ready",
            "whatsapp_status": "connected",
            "created_at": business.created_at.isoformat() if business.created_at else None,
            "updated_at": business.updated_at.isoformat() if business.updated_at else None
        }), 201
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error creating business: {e}")
        return jsonify({"error": "שגיאה ביצירת העסק"}), 500

@biz_mgmt_bp.route('/api/admin/business/<int:business_id>', methods=['PUT'])
@require_api_auth(['system_admin'])  # BUILD 138: Only system_admin can update businesses
def update_business(business_id):
    """Update business details"""
    try:
        business = Business.query.get(business_id)
        if not business:
            return jsonify({"error": "עסק לא נמצא"}), 404
        
        data = request.get_json()
        
        # Update name if provided
        if 'name' in data and data['name']:
            # Check for duplicate names (excluding current business)
            existing = Business.query.filter(
                Business.name == data['name'],
                Business.id != business_id
            ).first()
            if existing:
                return jsonify({"error": "שם העסק כבר קיים"}), 409
            business.name = data['name']
        
        # Update phone if provided
        if 'defaultPhoneE164' in data and data['defaultPhoneE164']:
            business.phone_e164 = data['defaultPhoneE164']
        
        # Update phone_e164 (alternative field name)
        if 'phone_e164' in data and data['phone_e164']:
            business.phone_e164 = data['phone_e164']
        
        # Update business type if provided
        if 'business_type' in data and data['business_type']:
            business.business_type = data['business_type']
        
        # Update status if provided
        if 'is_active' in data:
            business.is_active = bool(data['is_active'])
        
        # Update WhatsApp number if provided
        if 'whatsapp_number' in data:
            business.whatsapp_number = data['whatsapp_number']
        
        # Update greeting messages if provided
        if 'greeting_message' in data:
            business.greeting_message = data['greeting_message']
        
        if 'whatsapp_greeting' in data:
            business.whatsapp_greeting = data['whatsapp_greeting']
        
        # Update system prompt if provided
        if 'system_prompt' in data:
            business.system_prompt = data['system_prompt']
        
        # Update voice message if provided
        if 'voice_message' in data:
            business.voice_message = data['voice_message']
        
        # Update working hours if provided
        if 'working_hours' in data:
            business.working_hours = data['working_hours']
        
        # Update permissions if provided
        if 'phone_permissions' in data:
            business.phone_permissions = bool(data['phone_permissions'])
        
        if 'whatsapp_permissions' in data:
            business.whatsapp_permissions = bool(data['whatsapp_permissions'])
        
        # Update feature flags if provided
        if 'calls_enabled' in data:
            business.calls_enabled = bool(data['calls_enabled'])
        
        if 'crm_enabled' in data:
            business.crm_enabled = bool(data['crm_enabled'])
        
        if 'whatsapp_enabled' in data:
            business.whatsapp_enabled = bool(data['whatsapp_enabled'])
        
        if 'payments_enabled' in data:
            business.payments_enabled = bool(data['payments_enabled'])
        
        if 'default_provider' in data:
            business.default_provider = data['default_provider']
        
        business.updated_at = datetime.utcnow()
        db.session.commit()
        
        logger.info(f"Updated business {business_id}")
        
        return jsonify({
            "id": business.id,
            "name": business.name,
            "phone_e164": business.phone_e164,
            "whatsapp_number": business.whatsapp_number or "",
            "greeting_message": business.greeting_message or "",
            "whatsapp_greeting": business.whatsapp_greeting or "",
            "system_prompt": business.system_prompt or "",
            "voice_message": business.voice_message or "",
            "working_hours": business.working_hours or "08:00-18:00",
            "phone_permissions": business.phone_permissions,
            "whatsapp_permissions": business.whatsapp_permissions,
            "calls_enabled": business.calls_enabled,
            "crm_enabled": business.crm_enabled,
            "whatsapp_enabled": business.whatsapp_enabled,
            "payments_enabled": business.payments_enabled,
            "default_provider": business.default_provider or "paypal",
            "business_type": business.business_type,
            "is_active": business.is_active,
            "status": "active" if business.is_active else "inactive",
            "call_status": "ready",
            "whatsapp_status": "connected",
            "created_at": business.created_at.isoformat() if business.created_at else None,
            "updated_at": business.updated_at.isoformat() if business.updated_at else None
        })
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating business {business_id}: {e}")
        return jsonify({"error": "שגיאה בעדכון העסק"}), 500

@biz_mgmt_bp.route('/api/admin/business/<int:business_id>', methods=['DELETE'])
@require_api_auth(['admin'])
def delete_business(business_id):
    """Delete business with name confirmation"""
    try:
        business = Business.query.get(business_id)
        if not business:
            return jsonify({"error": "עסק לא נמצא"}), 404
        
        data = request.get_json()
        confirmation_name = data.get('confirmation_name', '').strip()
        
        # Check name confirmation
        if confirmation_name != business.name:
            return jsonify({
                "error": "שם העסק שהוזן אינו תואם. אנא הזן את השם המדויק לאישור המחיקה.",
                "expected": business.name,
                "received": confirmation_name
            }), 400
        
        business_name = business.name
        
        # Delete business (cascade will handle related records)
        db.session.delete(business)
        db.session.commit()
        
        logger.info(f"Deleted business {business_id}: {business_name}")
        
        return jsonify({
            "success": True,
            "message": f"העסק '{business_name}' נמחק בהצלחה"
        })
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error deleting business {business_id}: {e}")
        import traceback
        logger.error(f"Full traceback: {traceback.format_exc()}")
        return jsonify({"error": "שגיאה במחיקת העסק"}), 500

@biz_mgmt_bp.route('/api/admin/business/<int:business_id>/change-password', methods=['POST'])
@require_api_auth(['admin', 'system_admin', 'owner'])
def change_business_password(business_id):
    """Change password for business owner (tenant-scoped)"""
    try:
        current_user = session.get('user')
        current_role = current_user.get('role') if current_user else None
        
        # ✅ SECURITY: Only system_admin can reset any business, owner only their own
        if current_role == 'system_admin' or current_role == 'admin':
            pass  # System admin can reset any business
        elif current_role == 'owner':
            # Owner can only reset password for their own business
            if current_user.get('business_id') != business_id:
                return jsonify({"error": "Forbidden: Can only reset password for your own business"}), 403
        else:
            return jsonify({"error": "Forbidden: Insufficient permissions"}), 403
        
        data = request.get_json()
        new_password = data.get('password')
        
        if not new_password or len(new_password) < 6:
            return jsonify({"error": "הסיסמה חייבת להכיל לפחות 6 תווים"}), 400
        
        # Find business owner user
        owner_user = User.query.filter_by(
            business_id=business_id,
            role='owner'
        ).first()
        
        if not owner_user:
            return jsonify({"error": "לא נמצא בעלים לעסק זה"}), 404
        
        # Update password
        owner_user.password_hash = generate_password_hash(new_password)
        db.session.commit()
        
        logger.info(f"Changed password for business {business_id} owner by {current_user.get('email') if current_user else 'unknown'}")
        
        return jsonify({"success": True, "message": "סיסמה שונתה בהצלחה"})
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error changing password for business {business_id}: {e}")
        return jsonify({"error": "שגיאה בשינוי הסיסמה"}), 500

# =============================================================================
# USER MANAGEMENT ENDPOINTS (Admin Only)
# =============================================================================

@biz_mgmt_bp.route('/api/admin/user', methods=['POST'])
@require_api_auth(['admin'])
def create_user():
    """Create new user"""
    try:
        data = request.get_json()
        
        # Validate required fields
        required_fields = ['name', 'email', 'password', 'role']
        for field in required_fields:
            if not data.get(field):
                return jsonify({"error": f"חסר שדה: {field}"}), 400
        
        # Check if email exists
        existing_user = User.query.filter_by(email=data['email']).first()
        if existing_user:
            return jsonify({"error": "כתובת האימייל כבר רשומה במערכת"}), 409
        
        # Create user
        user = User()
        user.email = data['email']
        user.name = data['name']
        user.password_hash = generate_password_hash(data['password'])
        user.role = data['role']
        user.business_id = data.get('business_id') if data['role'] == 'business' else None
        user.is_active = True
        
        db.session.add(user)
        db.session.commit()
        
        logger.info(f"Created user {user.id} by admin")
        
        return jsonify({
            "success": True,
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "role": user.role
        }), 201
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error creating user: {e}")
        return jsonify({"error": "שגיאה ביצירת המשתמש"}), 500

@biz_mgmt_bp.route('/api/admin/user/<int:user_id>', methods=['GET'])
@require_api_auth(['admin'])
def get_user(user_id):
    """Get user details"""
    try:
        user = User.query.filter_by(id=user_id).first()
        if not user:
            return jsonify({"error": "משתמש לא נמצא"}), 404
        
        return jsonify({
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "role": user.role,
            "business_id": user.business_id,
            "is_active": user.is_active,
            "last_login": user.last_login.isoformat() if user.last_login else None
        })
    except Exception as e:
        logger.error(f"Error getting user {user_id}: {e}")
        return jsonify({"error": "שגיאה בטעינת נתוני המשתמש"}), 500

@biz_mgmt_bp.route('/api/admin/user/<int:user_id>', methods=['PUT'])
@require_api_auth(['admin'])
def update_user(user_id):
    """Update user details"""
    try:
        user = User.query.filter_by(id=user_id).first()
        if not user:
            return jsonify({"error": "משתמש לא נמצא"}), 404
        
        data = request.get_json()
        
        # Update fields
        if 'name' in data:
            user.name = data['name']
        if 'email' in data:
            # Check if email is already taken by another user
            existing = User.query.filter_by(email=data['email']).filter(User.id != user_id).first()
            if existing:
                return jsonify({"error": "כתובת האימייל כבר רשומה למשתמש אחר"}), 409
            user.email = data['email']
        if 'role' in data:
            user.role = data['role']
        if 'is_active' in data:
            user.is_active = data['is_active']
        
        db.session.commit()
        
        logger.info(f"Updated user {user_id} by admin")
        
        return jsonify({
            "success": True,
            "id": user.id,
            "name": user.name,
            "email": user.email,
            "role": user.role,
            "is_active": user.is_active
        })
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error updating user {user_id}: {e}")
        return jsonify({"error": "שגיאה בעדכון המשתמש"}), 500

@biz_mgmt_bp.route('/api/admin/user/<int:user_id>/change-password', methods=['POST'])
@require_api_auth(['admin', 'system_admin'])
def change_user_password(user_id):
    """Change user password - system admin only (no tenant scoping for security)"""
    try:
        user = User.query.filter_by(id=user_id).first()
        if not user:
            return jsonify({"error": "משתמש לא נמצא"}), 404
        
        data = request.get_json()
        new_password = data.get('password')
        
        if not new_password or len(new_password) < 6:
            return jsonify({"error": "הסיסמה חייבת להכיל לפחות 6 תווים"}), 400
        
        user.password_hash = generate_password_hash(new_password)
        db.session.commit()
        
        logger.info(f"Changed password for user {user_id} by admin")
        
        return jsonify({"success": True})
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error changing password for user {user_id}: {e}")
        return jsonify({"error": "שגיאה בשינוי הסיסמה"}), 500

@biz_mgmt_bp.route('/api/admin/user/<int:user_id>/toggle-status', methods=['POST'])
@require_api_auth(['admin'])
def toggle_user_status(user_id):
    """Toggle user active status"""
    try:
        user = User.query.filter_by(id=user_id).first()
        if not user:
            return jsonify({"error": "משתמש לא נמצא"}), 404
        
        # Don't allow disabling the current admin user
        current_user = session.get('user')
        if current_user and current_user.get('id') == user_id:
            return jsonify({"error": "לא ניתן להשהות את המשתמש הנוכחי"}), 400
        
        user.is_active = not user.is_active
        db.session.commit()
        
        status = "הופעל" if user.is_active else "הושהה"
        logger.info(f"User {user_id} {status} by admin")
        
        return jsonify({"success": True, "is_active": user.is_active})
        
    except Exception as e:
        db.session.rollback()
        logger.error(f"Error toggling status for user {user_id}: {e}")
        return jsonify({"error": "שגיאה בשינוי סטטוס המשתמש"}), 500

@biz_mgmt_bp.route('/api/admin/businesses/<int:business_id>/impersonate', methods=['POST', 'OPTIONS'])
@require_api_auth(['system_admin'])
def impersonate_business(business_id):
    """Allow system_admin to impersonate business - BUILD 142"""
    
    # Handle OPTIONS request for CORS preflight
    if request.method == 'OPTIONS':
        return '', 204
    
    try:
        logger.info(f"🔄 Impersonation attempt for business {business_id}")
        current_admin = session.get('user') or session.get('al_user')
        logger.info(f"📋 Current admin: {current_admin.get('email')} (role={current_admin.get('role')})")
        
        business = Business.query.filter_by(id=business_id).first()
        if not business:
            logger.error(f"❌ Business {business_id} not found")
            return jsonify({"error": "עסק לא נמצא"}), 404
        
        if not business.is_active:
            return jsonify({"error": "העסק אינו פעיל"}), 400
        
        # BUILD 144: Store original admin for banner display
        session["impersonator"] = current_admin  # ✅ CRITICAL: Save original user for /api/auth/me
        session["impersonating"] = True
        session["impersonated_tenant_id"] = business.id
        session.modified = True  # CRITICAL: Force Flask to save session
        
        logger.info(f"✅ System admin {current_admin.get('email')} impersonating business {business.id}")
        logger.info(f"🔍 Session state: impersonating={session.get('impersonating')}, tenant_id={session.get('impersonated_tenant_id')}, impersonator={session.get('impersonator')}")
        
        # BUILD 142: Return both formats for compatibility
        return jsonify({
            "success": True,
            "ok": True,  # Frontend expects this
            "impersonating": True,
            "impersonated_tenant_id": business.id,  # Frontend expects this
            "business_id": business.id,
            "business_name": business.name
        }), 200
        
    except Exception as e:
        logger.error(f"Error impersonating business {business_id}: {e}")
        return jsonify({"error": "שגיאה בהתחזות לעסק"}), 500

@biz_mgmt_bp.route('/api/admin/impersonate/exit', methods=['POST', 'OPTIONS'])
@require_api_auth(['system_admin'])
def exit_impersonation():
    """Exit impersonation and restore original user - BUILD 142"""
    
    # Handle OPTIONS request for CORS preflight
    if request.method == 'OPTIONS':
        return '', 204
    
    try:
        logger.info("🔄 Exiting impersonation")
        
        # BUILD 144: Clear ALL impersonation keys
        session.pop("impersonator", None)  # ✅ Clear original user
        session.pop("impersonating", None)
        session.pop("impersonated_tenant_id", None)
        session.modified = True  # Force session save
        
        logger.info(f"✅ Successfully exited impersonation, restored: {session.get('user') or session.get('al_user')}")
        
        # BUILD 142: Return both formats for compatibility
        return jsonify({
            "success": True,
            "ok": True,  # Frontend expects this
            "impersonating": False
        }), 200
        
    except Exception as e:
        logger.error(f"Error exiting impersonation: {e}")
        return jsonify({"error": "שגיאה ביציאה מהתחזות"}), 500

# === ADDITIONAL BUSINESS ENDPOINTS FROM api_business.py ===

# Business current info route
@biz_mgmt_bp.route('/api/business/current', methods=['GET'])
@require_api_auth(['system_admin', 'owner', 'admin', 'manager', 'business'])
def get_current_business():
    """Get current business details for authenticated user"""
    try:
        from flask import request, g, session
        
        business_id = g.get('tenant') or getattr(g, 'business_id', None)
        if not business_id:
            # 🔥 BUILD 186 FIX: Safely handle None values from session
            user = session.get('user') or session.get('al_user') or {}
            business_id = session.get('impersonated_tenant_id') or (user.get('business_id') if isinstance(user, dict) else None)
        
        if not business_id:
            logger.warning("No business context found in get_current_business")
            return jsonify({"error": "No business context found"}), 400
            
        business = Business.query.filter_by(id=business_id).first()
        if not business:
            return jsonify({"error": "Business not found"}), 404
            
        # 🔥 BUILD 186 FIX: Handle missing database columns gracefully
        settings = None
        try:
            settings = BusinessSettings.query.filter_by(tenant_id=business_id).first()
        except Exception as settings_err:
            logger.warning(f"Could not load settings for business {business_id} (DB schema issue): {settings_err}")
            # Continue with settings=None - will use defaults
        
        # 🔥 BUILD 186 FIX: Use getattr with fallbacks to prevent 500 errors if columns don't exist
        return jsonify({
            "id": business.id,
            "name": business.name,
            "phone_number": getattr(settings, 'phone_number', None) or business.phone_e164 if settings else business.phone_e164,
            "email": getattr(settings, 'email', None) or f"office@{business.name.lower().replace(' ', '-')}.co.il" if settings else f"office@{business.name.lower().replace(' ', '-')}.co.il",
            "address": getattr(settings, 'address', "") if settings else "",
            "working_hours": getattr(settings, 'working_hours', None) or business.working_hours if settings else business.working_hours,
            "timezone": getattr(settings, 'timezone', "Asia/Jerusalem") if settings else "Asia/Jerusalem",
            # 🔥 BUILD 138: Appointment settings
            "slot_size_min": getattr(settings, 'slot_size_min', 60) if settings else 60,
            "allow_24_7": getattr(settings, 'allow_24_7', False) if settings else False,
            "booking_window_days": getattr(settings, 'booking_window_days', 30) if settings else 30,
            "min_notice_min": getattr(settings, 'min_notice_min', 0) if settings else 0,
            "opening_hours_json": getattr(settings, 'opening_hours_json', None) if settings else None,
            # 🔥 BUILD 177: Generic Webhook
            "generic_webhook_url": getattr(settings, 'generic_webhook_url', None) if settings else None,
            # 🔥 BUILD 183: Separate inbound/outbound webhooks
            "inbound_webhook_url": getattr(settings, 'inbound_webhook_url', None) if settings else None,
            "outbound_webhook_url": getattr(settings, 'outbound_webhook_url', None) if settings else None,
            # 🔥 BUILD 163: Auto hang-up settings
            "auto_end_after_lead_capture": getattr(settings, 'auto_end_after_lead_capture', False) if settings else False,
            "auto_end_on_goodbye": getattr(settings, 'auto_end_on_goodbye', False) if settings else False,
            # 🔥 BUILD 163: Bot speaks first
            "bot_speaks_first": getattr(settings, 'bot_speaks_first', False) if settings else False,
            # 🔥 BUILD 186: Calendar scheduling toggle
            "enable_calendar_scheduling": getattr(settings, 'enable_calendar_scheduling', True) if settings else True,
            # 🔥 BUILD 164: Smart Call Control Settings
            "silence_timeout_sec": getattr(settings, 'silence_timeout_sec', 15) if settings else 15,
            "silence_max_warnings": getattr(settings, 'silence_max_warnings', 2) if settings else 2,
            "smart_hangup_enabled": getattr(settings, 'smart_hangup_enabled', True) if settings else True,
            # 🔥 BUILD 340: Default to name + preferred_time (phone collected at end, not required)
            "required_lead_fields": getattr(settings, 'required_lead_fields', ["name", "preferred_time"]) if settings else ["name", "preferred_time"],
            # 🔥 BUILD 204: Dynamic STT Vocabulary
            "stt_vocabulary_json": getattr(settings, 'stt_vocabulary_json', None) if settings else None,
            "business_context": getattr(settings, 'business_context', None) if settings else None,
            # 🔥 BUILD 309: SIMPLE_MODE settings
            "call_goal": getattr(settings, 'call_goal', 'lead_only') if settings else 'lead_only',
            "confirm_before_hangup": getattr(settings, 'confirm_before_hangup', True) if settings else True
        })
        
    except Exception as e:
        logger.error(f"Error getting current business: {e}")
        return jsonify({"error": "Internal server error"}), 500

@biz_mgmt_bp.route('/api/business/current/settings', methods=['PUT'])
@csrf.exempt
@require_api_auth(['system_admin', 'owner', 'admin', 'manager', 'business'])
def update_current_business_settings():
    """Update current business settings"""
    try:
        from flask import request, session, g
        
        data = request.get_json()
        if not data:
            return jsonify({"error": "Invalid JSON data"}), 400
            
        business_id = g.get('tenant') or getattr(g, 'business_id', None)
        if not business_id:
            # 🔥 BUILD 186 FIX: Safely handle None values from session
            user = session.get('user') or session.get('al_user') or {}
            business_id = session.get('impersonated_tenant_id') or (user.get('business_id') if isinstance(user, dict) else None)
        
        if not business_id:
            return jsonify({"error": "No business context found"}), 400
        
        logger.info(f"Updating settings for business {business_id}")
            
        business = Business.query.filter_by(id=business_id).first()
        if not business:
            return jsonify({"error": "Business not found"}), 404
            
        # Update business name if provided
        if 'business_name' in data:
            business.name = data['business_name']
            
        # Get or create settings
        settings = BusinessSettings.query.filter_by(tenant_id=business_id).first()
        if not settings:
            settings = BusinessSettings()
            settings.tenant_id = business_id
            db.session.add(settings)
            
        # Update settings fields
        if 'phone_number' in data:
            settings.phone_number = data['phone_number']
            # Also update the main business table
            business.phone_e164 = data['phone_number']
        if 'email' in data:
            settings.email = data['email']
        if 'address' in data:
            settings.address = data['address']
        if 'working_hours' in data:
            settings.working_hours = data['working_hours']
            # Also update the main business table
            business.working_hours = data['working_hours']
        if 'timezone' in data:
            settings.timezone = data['timezone']
        
        # 🔥 BUILD 138: Appointment settings
        appointment_settings_changed = False
        
        if 'slot_size_min' in data:
            settings.slot_size_min = int(data['slot_size_min'])
            appointment_settings_changed = True
        if 'allow_24_7' in data:
            settings.allow_24_7 = bool(data['allow_24_7'])
            appointment_settings_changed = True
        if 'booking_window_days' in data:
            settings.booking_window_days = int(data['booking_window_days'])
            appointment_settings_changed = True
        if 'min_notice_min' in data:
            settings.min_notice_min = int(data['min_notice_min'])
            appointment_settings_changed = True
        if 'opening_hours_json' in data:
            settings.opening_hours_json = data['opening_hours_json']
            appointment_settings_changed = True
        
        # 🔥 BUILD 177: Generic Webhook
        if 'generic_webhook_url' in data:
            settings.generic_webhook_url = data['generic_webhook_url'] or None
        
        # 🔥 BUILD 183: Separate inbound/outbound webhooks
        if 'inbound_webhook_url' in data:
            settings.inbound_webhook_url = data['inbound_webhook_url'] or None
        if 'outbound_webhook_url' in data:
            settings.outbound_webhook_url = data['outbound_webhook_url'] or None
        
        # 🔥 BUILD 163: Auto hang-up settings
        if 'auto_end_after_lead_capture' in data:
            settings.auto_end_after_lead_capture = bool(data['auto_end_after_lead_capture'])
        if 'auto_end_on_goodbye' in data:
            settings.auto_end_on_goodbye = bool(data['auto_end_on_goodbye'])
        
        # 🔥 BUILD 163: Bot speaks first setting
        if 'bot_speaks_first' in data:
            settings.bot_speaks_first = bool(data['bot_speaks_first'])
        
        # 🔥 BUILD 186: Calendar scheduling toggle
        if 'enable_calendar_scheduling' in data:
            settings.enable_calendar_scheduling = bool(data['enable_calendar_scheduling'])
        
        # 🔥 BUILD 164: Smart Call Control Settings
        if 'silence_timeout_sec' in data:
            settings.silence_timeout_sec = int(data['silence_timeout_sec'])
        if 'silence_max_warnings' in data:
            settings.silence_max_warnings = int(data['silence_max_warnings'])
        if 'smart_hangup_enabled' in data:
            settings.smart_hangup_enabled = bool(data['smart_hangup_enabled'])
        if 'required_lead_fields' in data:
            settings.required_lead_fields = data['required_lead_fields']
        
        # 🔥 BUILD 204: Dynamic STT Vocabulary
        if 'stt_vocabulary_json' in data:
            vocab = data['stt_vocabulary_json']
            # Validate vocabulary structure and limits
            if vocab:
                if isinstance(vocab, dict):
                    # Enforce limits: max 20 items per category, max 50 chars per item
                    validated_vocab = {}
                    for key in ['services', 'staff', 'products', 'locations']:
                        items = vocab.get(key, [])
                        if isinstance(items, list):
                            validated_vocab[key] = [str(item)[:50] for item in items[:20]]
                    settings.stt_vocabulary_json = validated_vocab
                else:
                    logger.warning(f"⚠️ Invalid vocabulary format for business {business_id}, skipping")
            else:
                settings.stt_vocabulary_json = None
            # Clear vocabulary cache when updated
            try:
                from server.services.dynamic_stt_service import clear_vocabulary_cache
                clear_vocabulary_cache(business_id)
            except Exception as e:
                logger.warning(f"⚠️ Failed to clear STT vocabulary cache: {e}")
        if 'business_context' in data:
            # Limit business context to 500 chars
            context = data['business_context']
            if context:
                settings.business_context = str(context)[:500]
            else:
                settings.business_context = None
        
        # 🔥 BUILD 309: SIMPLE_MODE settings
        if 'call_goal' in data:
            goal = data['call_goal']
            if goal in ('lead_only', 'appointment'):
                settings.call_goal = goal
            else:
                settings.call_goal = 'lead_only'  # Default fallback
        if 'confirm_before_hangup' in data:
            settings.confirm_before_hangup = bool(data['confirm_before_hangup'])
            
        # Track who updated - 🔥 BUILD 186 FIX: Safely handle None values
        al_user = session.get('al_user') or {}
        user_email = al_user.get('email', 'Unknown') if isinstance(al_user, dict) else 'Unknown'
        settings.updated_by = user_email
        settings.updated_at = datetime.now()
        
        db.session.commit()
        
        # 🔄 Invalidate ALL caches when appointment settings change
        if appointment_settings_changed:
            # 1. Policy cache (business hours, slots, etc.)
            from server.policy.business_policy import invalidate_business_policy_cache
            invalidate_business_policy_cache(business_id)
            logger.info(f"🔄 Policy cache cleared for business {business_id}")
            
            # 2. 🔥 CRITICAL: Prompt cache (contains hours in system prompt!)
            try:
                from server.services.ai_service import invalidate_business_cache
                invalidate_business_cache(business_id)
                logger.info(f"🔄 Prompt+Agent cache cleared for business {business_id}")
            except Exception as e:
                logger.warning(f"⚠️ Failed to invalidate prompt cache: {e}")
            
            logger.info(f"✅ ALL CACHES INVALIDATED for business {business_id} - new hours will apply immediately!")
        
        return jsonify({
            "success": True,
            "message": "הגדרות עסק עודכנו בהצלחה"
        })
        
    except Exception as e:
        import traceback
        error_trace = traceback.format_exc()
        logger.error(f"Error updating business settings: {e}")
        logger.error(f"Traceback: {error_trace}")
        print(f"❌ Settings save error: {e}")
        print(f"❌ Traceback: {error_trace}")
        db.session.rollback()
        return jsonify({"error": f"Internal server error: {str(e)}"}), 500


# ===== FAQ MANAGEMENT ROUTES =====

@biz_mgmt_bp.route('/api/business/faqs', methods=['GET'])
@csrf.exempt  # ✅ Exempt from CSRF for authenticated API
@require_api_auth(['business', 'admin', 'manager'])
def get_business_faqs():
    """Get all FAQs for current business"""
    try:
        business_id = getattr(g, 'business_id', None)
        if not business_id:
            return jsonify({'error': 'No business context found'}), 400
        
        faqs = FAQ.query.filter_by(business_id=business_id, is_active=True).order_by(FAQ.order_index, FAQ.id).all()
        
        return jsonify([{
            'id': faq.id,
            'question': faq.question,
            'answer': faq.answer,
            'intent_key': faq.intent_key,
            'patterns_json': faq.patterns_json,
            'channels': faq.channels,
            'priority': faq.priority,
            'lang': faq.lang,
            'order_index': faq.order_index,
            'created_at': faq.created_at.isoformat() if faq.created_at else None
        } for faq in faqs])
    except Exception as e:
        logger.error(f'Error getting FAQs: {e}')
        return jsonify({'error': 'Internal server error'}), 500

@biz_mgmt_bp.route('/api/business/faqs', methods=['POST'])
@csrf.exempt  # ✅ Exempt from CSRF for authenticated API
@require_api_auth(['business', 'admin', 'manager'])
def create_faq():
    """Create new FAQ"""
    try:
        business_id = getattr(g, 'business_id', None)
        if not business_id:
            return jsonify({'error': 'No business context found'}), 400
        
        data = request.get_json()
        if not data or not data.get('question') or not data.get('answer'):
            return jsonify({'error': 'Question and answer are required'}), 400
        
        # Get max order_index
        max_order = db.session.query(db.func.max(FAQ.order_index)).filter_by(business_id=business_id).scalar() or 0
        
        try:
            normalized_patterns = normalize_patterns(data.get('patterns_json'))
        except ValueError as e:
            return jsonify({'error': f'Invalid patterns_json: {str(e)}'}), 400
        
        faq = FAQ(
            business_id=business_id,
            question=data['question'],
            answer=data['answer'],
            intent_key=data.get('intent_key'),
            patterns_json=normalized_patterns,
            channels=data.get('channels', 'voice'),
            priority=data.get('priority', 0),
            lang=data.get('lang', 'he-IL'),
            order_index=max_order + 1
        )
        db.session.add(faq)
        db.session.commit()
        
        # Invalidate FAQ cache after creation
        try:
            from server.services.faq_cache import faq_cache
            faq_cache.invalidate(business_id)
        except Exception as e:
            logger.warning(f"FAQ cache invalidation failed: {e}")
        
        return jsonify({
            'id': faq.id,
            'question': faq.question,
            'answer': faq.answer,
            'intent_key': faq.intent_key,
            'patterns_json': faq.patterns_json,
            'channels': faq.channels,
            'priority': faq.priority,
            'lang': faq.lang,
            'order_index': faq.order_index,
            'created_at': faq.created_at.isoformat() if faq.created_at else None
        }), 201
    except Exception as e:
        logger.error(f'Error creating FAQ: {e}')
        db.session.rollback()
        return jsonify({'error': 'Internal server error'}), 500

@biz_mgmt_bp.route('/api/business/faqs/<int:faq_id>', methods=['PUT'])
@csrf.exempt  # ✅ Exempt from CSRF for authenticated API
@require_api_auth(['business', 'admin', 'manager'])
def update_faq(faq_id):
    """Update FAQ"""
    try:
        business_id = getattr(g, 'business_id', None)
        if not business_id:
            return jsonify({'error': 'No business context found'}), 400
        
        faq = FAQ.query.filter_by(id=faq_id, business_id=business_id).first()
        if not faq:
            return jsonify({'error': 'FAQ not found'}), 404
        
        data = request.get_json()
        if 'question' in data:
            faq.question = data['question']
        if 'answer' in data:
            faq.answer = data['answer']
        if 'intent_key' in data:
            faq.intent_key = data['intent_key']
        if 'patterns_json' in data:
            try:
                faq.patterns_json = normalize_patterns(data['patterns_json'])
            except ValueError as e:
                return jsonify({'error': f'Invalid patterns_json: {str(e)}'}), 400
        if 'channels' in data:
            faq.channels = data['channels']
        if 'priority' in data:
            faq.priority = data['priority']
        if 'lang' in data:
            faq.lang = data['lang']
        if 'order_index' in data:
            faq.order_index = data['order_index']
        
        faq.updated_at = datetime.utcnow()
        db.session.commit()
        
        # Invalidate FAQ cache after update
        try:
            from server.services.faq_cache import faq_cache
            faq_cache.invalidate(business_id)
        except Exception as e:
            logger.warning(f"FAQ cache invalidation failed: {e}")
        
        return jsonify({
            'id': faq.id,
            'question': faq.question,
            'answer': faq.answer,
            'intent_key': faq.intent_key,
            'patterns_json': faq.patterns_json,
            'channels': faq.channels,
            'priority': faq.priority,
            'lang': faq.lang,
            'order_index': faq.order_index,
            'updated_at': faq.updated_at.isoformat() if faq.updated_at else None
        })
    except Exception as e:
        logger.error(f'Error updating FAQ: {e}')
        db.session.rollback()
        return jsonify({'error': 'Internal server error'}), 500

@biz_mgmt_bp.route('/api/business/faqs/<int:faq_id>', methods=['DELETE'])
@csrf.exempt  # ✅ Exempt from CSRF for authenticated API
@require_api_auth(['business', 'admin', 'manager'])
def delete_faq(faq_id):
    """Delete FAQ (soft delete by marking inactive)"""
    try:
        business_id = getattr(g, 'business_id', None)
        if not business_id:
            return jsonify({'error': 'No business context found'}), 400
        
        faq = FAQ.query.filter_by(id=faq_id, business_id=business_id).first()
        if not faq:
            return jsonify({'error': 'FAQ not found'}), 404
        
        faq.is_active = False
        db.session.commit()
        
        # Invalidate FAQ cache after deletion
        try:
            from server.services.faq_cache import faq_cache
            faq_cache.invalidate(business_id)
        except Exception as e:
            logger.warning(f"FAQ cache invalidation failed: {e}")
        
        return jsonify({'success': True}), 200
    except Exception as e:
        logger.error(f'Error deleting FAQ: {e}')
        db.session.rollback()
        return jsonify({'error': 'Internal server error'}), 500

