# Server configuration module
from .calls import SIMPLE_MODE

__all__ = ['SIMPLE_MODE']
